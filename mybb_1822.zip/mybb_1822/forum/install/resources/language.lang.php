﻿<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */

/* INSTALL LANGUAGE VARIABLES */
$l['none'] = 'Yok';
$l['not_installed'] = 'Yüklü Değil';
$l['installed'] = 'Yüklü';
$l['not_writable'] = 'Yazma İzinleri Kapalı';
$l['writable'] = 'Yazma İzinleri Açık';
$l['done'] = 'onay';
$l['next'] = 'ileri';
$l['error'] = 'hata';
$l['multi_byte'] = 'Multi-Byte';
$l['recheck'] = 'Kontrol et';

$l['title'] = "MyBB Kurulum Sihirbazı";
$l['welcome'] = 'Hoşgeldiniz';
$l['license_agreement'] = 'Lisans Anlaşması';
$l['req_check'] = 'Sistem Gereksinimleri';
$l['db_config'] = 'Veritabanı Ayarları';
$l['table_creation'] = 'Veritabanı Tabloları';
$l['data_insertion'] = 'Tablolar Oluşturuluyor';
$l['theme_install'] = 'Tema Yükleniyor';
$l['board_config'] = 'Forum Ayaları';
$l['admin_user'] = 'Yönetici Ayarları';
$l['finish_setup'] = 'Kurulum Tamamlandı';
$l['upgrade_complete'] = 'Upgrade Complete';

$l['table_population'] = 'Tablo Oluşum Bilgileri';
$l['theme_installation'] = 'Tema Kurulumu';
$l['create_admin'] = 'Yönetici Hesabı Oluşturma';

$l['already_installed'] = "MyBB zaten kurulu olduğu tespit edildi";
$l['mybb_already_installed'] = "<p>MyBB forum kurulum sihirbazına hoşgeldiniz. {1}. MyBB zaten kurulu olduğu tespit edildi.</p>
<p>Lütfen yapmak istediğiniz işlemi seçiniz:</p>

<div class=\"border_wrapper upgrade_note\" style=\"padding: 4px;\">
	<h3>Şu anki sürümünüz {1} sürümünden eski. Lütfen sürümünüzü MyBB {1} sürümüne yülseltin. <span style=\"font-size: 80%; color: maroon;\">(Önerilen)</span></h3>
	<p>Bu seçenek şu anki sürümünüzü, MyBB {1} sürümüne yükseltmenize olanak sağlar..</p>
	<p>Şu anki versiyonunuzda bulunan, tüm konular,yorumlar ve kullanıcılar vb. güncelleme işleminden sonra yeni versiyona aktarılacaktır.</p>
	<form method=\"post\" action=\"upgrade.php\">
		<div class=\"next_button\"><input type=\"submit\" class=\"submit_button\" value=\"Upgrade to MyBB {1} &raquo;\" /></div>
	</form>
</div>

<div style=\"padding: 4px;\">
	<h3>Yeni bir MyBB forum kurulumu yapın.</h3>
	<p>This option will <span style=\"color: red;\">Bu işlem, kurulu sisteminizi silerek</span> yeni bir MyBB forum kurmanızı sağlar.</p>
	<p>Bu işlemin gerçekleşmesi için şu anda kurulu olan MyBB forumunuzu silerek, yeni bir MyBB forum kurulumu yapabilirsiniz.</p>
	<form method=\"post\" action=\"index.php\" onsubmit=\"return confirm('Yeni bir MyBB forum kurulumu gerçekleştirmek istediğinizden eminmisiniz?\\n\\nBu işlem şu anda kurulu olan forumunuzu silecektir ve geri alınamaz.');\">
		<input type=\"hidden\" name=\"action\" value=\"intro\" />
		<div class=\"next_button\"><input type=\"submit\" class=\"submit_button\" value=\"Install MyBB {1} &raquo;\" /></div>
	</form>
</div>";

$l['mybb_incorrect_folder'] = "<div class=\"border_wrapper upgrade_note\" style=\"padding: 4px;\">
	<h3>MyBB kurulum dosyalarını \"Upload\" klasörüyle birlikte yüklediğinizi tespit edildi.</h3>
	<p>Kurulum dosyalarını eğer \"Upload\" klasörüyle yüklediyseniz, kurulum işlemi başlamayabilir, \"Upload\" Bu sorun hakkında ayrınlı bilgi için.<br /><br />Daha faza bilgi için <a href=\"https://docs.mybb.com/1.8/install/#uploading-files\" target=\"_blank\" rel=\"noopener\">MyBB Resmi Destek Sayfası</a>.</p>
</div>";

$l['welcome_step'] = '<p><a href="http://www.onebe.net" title="MyBB Türkçe Çeviri Kurulum Sitesi" target="_blank"><b>ONEBE.NET</b></a> {1}. MyBB Türkçe Kurulum Sihirbazına Hoşgeldiniz.</p>
<p> MyBB kurulum sihirbazı ile aşağıdaki listede yer alan adımları sırasıyla gerçekleştirdikten sonra, kurulum işlemini tamamlayacaksınız.</p>
<ul>
<li>MyBB için sistem geresinim kontrolü</li>
	<li>MySQL Veritabanı Ayarları</li>
	<li>Veritabanı Tablolarının Oluşturulması</li>
	<li>Varsayılan Verilerin Yüklenmesi</li>
	<li>Varsayılan Tema ve Şablonların Yüklenmesi</li>
	<li>Forum Ayaları ve Yönetici Hesabının Oluşturulması</li>
	<li>Kurulumun Sonu</li>
</ul>
<p>Üsteki adımları yer alan her aşamayı tamamlamak için [İleri] tuşuna tıklayın..</p>
<p>Lisans sözleşmesini görüntülemek için İLERİ tıklayın.</p>
<p><input type="checkbox" name="allow_anonymous_info" value="1" id="allow_anonymous" checked="checked" /> <label for="allow_anonymous"> MyBB için sunucu özellikleriniz hakkında anonim istatistikler gönderilsin mi?</label> (<a href="https://docs.mybb.com/1.8/install/anonymous-statistics/" style="color: #555;" target="_blank"><small>Hangi bilgiler gönderilir?</small></a>)</p>';

$l['license_step'] = '<div class="license_agreement">
{1}
</div>
<p><strong>Lisans sözleşmesini kabul ediyorsanız İLERİ tuşuna basınız.</strong></p>';


$l['req_step_top'] = '<p>Bu kısımda kurulum öncesi sistem gereksinimleri ve ayarlarını burdan kontrol edebilirsiniz.</p>';
$l['req_step_reqtable'] = '<div class="border_wrapper">
			<div class="title">Sistem Gereksinimlerinin kontrolü</div>
		<table class="general" cellspacing="0">
		<thead>
			<tr>
				<th colspan="2" class="first last">Sistem Gereksinimleri</th>
			</tr>
		</thead>
		<tbody>
		<tr class="first">
			<td class="first">PHP Version:</td>
			<td class="last alt_col">{1}</td>
		</tr>
		<tr class="alt_row">
			<td class="first">Desteklenen Veritabanları:</td>
			<td class="last alt_col">{2}</td>
		</tr>
		<tr class="alt_row">
			<td class="first">Desteklenen Çeviri Uzantıları:</td>
			<td class="last alt_col">{3}</td>
		</tr>
		<tr class="alt_row">
			<td class="first">PHP XML Uzantıları:</td>
			<td class="last alt_col">{4}</td>
		</tr>
		<tr class="alt_row">
			<td class="first">Dosyasının Yazma İzinleri:</td>
			<td class="last alt_col">{5}</td>
		</tr>
		<tr>
			<td class="first">Ayarların yazma İzinleri:</td>
			<td class="last alt_col">{6}</td>
		</tr>
		<tr>
			<td class="first">Önbellek Yazma İzinleri:</td>
			<td class="last alt_col">{7}</td>
		</tr>
		<tr class="alt_row">
			<td class="first">Dosya Yükleme Yazma İzinleri:</td>
			<td class="last alt_col">{8}</td>
		</tr>
		<tr class="last">
			<td class="first">Avatar Klasörünün Yazma İzinleri:</td>
			<td class="last alt_col">{9}</td>
		</tr>
		</tbody>
		</table>
		</div>';
$l['req_step_reqcomplete'] = '<p><strong>Tebrikler, MyBB kurulumu için sistem gereksinimlerini başarıyla sağladınız...</strong></p>
<p>Lütfen, kuruluma devam edebilmek için İLERİ tuşuna tıklayınız.</p>';

$l['req_step_span_fail'] = '<span class="fail"><strong>{1}</strong></span>';
$l['req_step_span_pass'] = '<span class="pass">{1}</span>';

$l['req_step_error_box'] = '<p><strong>{1}</strong></p>';
$l['req_step_error_phpversion'] = 'MyBB kurulumu için gerekli minimum PHP sürümü 5.1.0 ve üzeridir. Sizin PHP sürümünüz .';
$l['req_step_error_dboptions'] = 'MyBB kurulumunu gerçekleştirmek için gerekli olan bir yada daha fazla veritabanı uzantısını sizin sunucunuz desteklemiyor.';
$l['req_step_error_xmlsupport'] = 'MyBB kurulumunun gerçekleşmesi için sunucunuzun PHP XML Handling desteklemesi gerekiyor.  bilgi için <a href="http://www.php.net/xml" target="_blank" rel="noopener">PHP.net</a> sitesini ziyaret edebilirsiniz.';
$l['req_step_error_configdefaultfile'] = 'MyBB kurulumunun gerçekleşmesi için (inc/config.default.php) dosyasının adını değiştirmeniz gerekiyor. Lütfen, <u>config.default.php</u> file to dosyasının adını <u>config.php</u> olarak değiştiriniz. Bu sorun hakkında <a href="https://mybb.com/support" target="_blank" rel="noopener">MyBB Resmi Destek Sitesi.</a>';
$l['req_step_error_configfile'] = '(./inc/config.php) dosyasının yazma izinleri kapalı. Lütfen, <u>config.php</u> dosyasının CHMOD izinlerini 777 yapınız. Bu sorun hakkında  bilgi için <a href="https://docs.mybb.com/1.8/administration/security/file-permissions" target="_blank" rel="noopener">chmod</a> izinleri için sayfayı ziyaret ediniz.';
$l['req_step_error_settingsfile'] = '(inc/settings.php) dosyasının yazma izinleri kapalı. Lütfen, settings.php dosyasının CHMOD izinlerini 777 yapınız. Bu sorun hakkında  bilgi için <a href="https://docs.mybb.com/1.8/administration/security/file-permissions" target="_blank" rel="noopener">chmod</a> izinleri için sayfayı ziyaret ediniz.';
$l['req_step_error_cachedir'] = '(cache/) klasörünün yazma izinleri kapalı. Lütfen, (cache/) klasörünün CHMOD izinlerini 777 yapınız. Bu sorun hakkında  bilgi için: <a href="https://docs.mybb.com/1.8/administration/security/file-permissions" target="_blank" rel="noopener">chmod</a> permissions izinleri için sayfayı ziyaret ediniz.';
$l['req_step_error_uploaddir'] = '(uploads/) klasörünün yazma izinleri kapalı. Lütfen, (uploads/) klasörünün CHMOD izinlerini 777 yapınız. Bu sorun hakkında  bilgi için <a href="https://docs.mybb.com/1.8/administration/security/file-permissions" target="_blank" rel="noopener">chmod</a> izinleri için sayfayı ziyaret ediniz.';
$l['req_step_error_avatardir'] = '(uploads/avatars/) klasörünün yazma izinleri kapalı. Lütfen, (avatars/) klasörünün CHMOD izinlerini 777 yapınız. Bu sorun hakkında  bilgi için <a href="https://docs.mybb.com/1.8/administration/security/file-permissions" target="_blank" rel="noopener">chmod</a> izinleri için sayfayı ziyaret ediniz.';
$l['req_step_error_cssddir'] = '(css/) klasörünün yazma izinleri kapalı. Lütfen, (css/) klasörünün CHMOD izinlerini 777 yapınız. Bu sorun hakkında  bilgi için <a href="https://docs.mybb.com/1.8/administration/security/file-permissions" target="_blank" rel="noopener">chmod</a> izinleri için sayfayı ziyaret ediniz.';
$l['req_step_error_tablelist'] = '<div class="error">
<h3>Hata</h3>
<p>MyBB kurulumu aşağıdaki hatalardan dolayı devam edemiyor. Lütfen aşağıdaki hataları düzeltip tekrar deneyin:</p>
{1}
</div>';


$l['db_step_config_db'] = '<p>MyBB forum kurulumunun devam edebilmesi için aşağıdaki kısımda veritabanı bilgilerinizi yazınız...</p>';
$l['db_step_config_table'] = '<div class="border_wrapper">
<div class="title">Veritabanı Yapılandırması</div>
<table class="general" cellspacing="0">
<tr>
	<th colspan="2" class="first last">Veritabanı Ayarları</th>
</tr>
<tr class="first">
	<td class="first"><label for="dbengine">Veritabanı yapısı:</label></td>
	<td class="last alt_col"><select name="dbengine" id="dbengine" onchange="updateDBSettings();">{1}</select></td>
</tr>
{2}
</table>
</div>
<p>Lütfen, kuruluma devam etmeden önce, girmiş olduğunuz bilgilerin doğruluğunu kontrol ederek, İLERİ tuşuna tıklayınız...</p>';

$l['database_settings'] = "Veritabanı Ayarları";
$l['database_path'] = "Veritabanı Yolu:";
$l['database_host'] = "Veritabanı Server Host Adı:";
$l['database_user'] = "Veritabanı Kullanıcı Adı:";
$l['database_pass'] = "Veritabanı Şifresi:";
$l['database_name'] = "Veritabanı Adı:";
$l['table_settings'] = "Tablo Ayarları";
$l['table_prefix'] = "Tablo Ön Eki:";
$l['table_encoding'] = "Tablo Formatı:";

$l['db_step_error_config'] = '<div class="error">
<h3>hata</h3>
<p>Kurulum sihirbazı aşağıdaki veritabanı bilgilerinin yanlış olduğunu tespit etti:</p>
{1}
<p>Üsteki tespit edilen hataları düzelterek, kurulum işlemine devam edebilirsiniz.</p>
</div>';
$l['db_step_error_invalidengine'] = 'Seçmiş olduğunuz veritabanı tipi geçersiz. Lütfen geçerli bir veritabanı seçeniz.';
$l['db_step_error_noconnect'] = 'Veritabanı ile bağlantı kuramadı. Girmiş olduğunuz ftp kullanıcı adı ve şifrenizin doğru olduğundan eminmisiniz?';
$l['db_step_error_nodbname'] = 'ile bağlantı kuralabilmesi için geçerli veritabanını seçiniz. Girmiş olduğunuz ftp kullanıcı adı ve şifrenizin doğru olduğundan eminmisiniz?';
$l['db_step_error_missingencoding'] = 'Tablo formatı için henüz bir seçim yapmadınız. Lütfen kuruluma devam etmeden önce, (\'UTF-8 Unicode\') formatının seçili olduğundan emin olun.';
$l['db_step_error_sqlite_invalid_dbname'] = 'Eğer SQLite veritabanı türünü kullanmak istiyorsanız, lütfen dosyaların bulunduğu dizinin ön ekini örnekteki gibi giriniz. (ön ek: /home/user/database.db).';
$l['db_step_error_invalid_tableprefix'] = 'Tablo ön eki için sadece (_) gibi alphanumeric karakterler içeren ön ek kullanabilirsiniz.<br />Lütfen kurulum işlemine devam etmeden önce geçerli bir tablo ön eki giriniz.';
$l['db_step_error_tableprefix_too_long'] = 'tablo ön eki için maksimum 40 karakter uzunluğunda bir ön ek kullanabilirsiniz.<br />Lütfen kurulum işlemine devam etmeden önce, izin verilen uzunlukta bir ön ek giriniz.';
$l['db_step_error_utf8mb4_error'] = '\'4-Byte UTF-8 Unicode\' gerekiyor, MySQL 5.5.3 sürümü gerekmektedir. Lütfen MySQL sürümünüzle uyumlu bir kodlama seçin...';

$l['tablecreate_step_connected'] = '<p>Veritabanı ile sunucu bağlantısı başarılı olarak tamamlandı.</p>
<p>Veritabanı Tipi: {1} {2}</p>
<p>MyBB için veritabanı tabloları başarıyla oluşturuldu</p>';
$l['tablecreate_step_created'] = 'tablo oluşturma {1}...';
$l['tablecreate_step_done'] = '<p>Tüm Tablolar oluşturuldu,kuruluma devam etmek için İLERİ tıklayın.</p>';

$l['populate_step_insert'] = '<p>Varsayılan temel tablolar oluşturuluyor.</p>';
$l['populate_step_inserted'] = '<p>Varsayılan veri bilgileri başarıyla oluşturuldu. Şimdi MyBB default tema ve şablonlarının kurulumu için lütfen, İLERİ tuşuna tıklayınız.</p>';


$l['theme_step_importing'] = '<p>Default Tema şablon dosyasını yükleme...</p>';
$l['theme_step_imported'] = '<p>Varsayılan Default tema ve şablonlar başarıyla yüklendi,FORUM AYARLARI için İLERİ tıklayın.</p>';


$l['config_step_table'] = '<p> Bu kısımda, aşağıdaki alanlara forum adı , forum adresi, çerez ve mail adres bilgilerinizi giriniz.Bu ayarları kurulum işlemi bittikten sonra, Admin Panelinden kolaylıkla değiştirebilirsiniz..</p>
		<div class="border_wrapper">
			<div class="title">Genel Forum Ayarları</div>
			<table class="general" cellspacing="0">
				<tbody>
				<tr>
					<th colspan="2" class="first last">Forum Detayları</th>
				</tr>
				<tr class="first">
					<td class="first"><label for="bbname">Forum adı:</label></td>
					<td class="last alt_col"><input type="text" class="text_input" name="bbname" id="bbname" value="{1}" /></td>
				</tr>
				<tr class="alt_row last">
					<td class="first"><label for="bburl">Forum URL\'si(sonunda slash kullanmayın!) </label></td>
					<td class="last alt_col"><input type="text" class="text_input" name="bburl" id="bburl" value="{2}" onkeyup="warnUser(this, \'This option was set automatically. Do not change it if you are not sure about the correct value, otherwise links on your forum may be broken.\')" onchange="warnUser(this, \'This option was set automatically. Do not change it if you are not sure about the correct value, otherwise links on your forum may be broken.\')" /></td>
				</tr>
				<tr>
					<th colspan="2" class="first last">Website Detayları</th>
				</tr>
				<tr>
					<td class="first"><label for="websitename">Website Adı:</label></td>
					<td class="last alt_col"><input type="text" class="text_input" name="websitename" id="websitename" value="{3}" /></td>
				</tr>
				<tr class="alt_row last">
					<td class="first"><label for="websiteurl">Website URL:</label></td>
					<td class="last alt_col"><input type="text" class="text_input" name="websiteurl" id="websiteurl" value="{4}" /></td>
				</tr>
				<tr>
					<th colspan="2" class="first last">Cookie Çerez Ayarları <a title="Çerez Hakkında bilgi için" target="_blank" rel="noopener" href="https://docs.mybb.com/1.8/development/cookies">(?)</a></th>
				</tr>
				<tr>
					<td class="first"><label for="cookiedomain">Cookie Çerez Domain:</label></td>
					<td class="last alt_col"><input type="text" class="text_input" name="cookiedomain" id="cookiedomain" value="{5}" onkeyup="warnUser(this, \'This option was set automatically. Do not change it if you are not sure about the correct value, otherwise logging in or out on your forum may be broken.\')" onchange="warnUser(this, \'This option was set automatically. Do not change it if you are not sure about the correct value, otherwise logging in or out on your forum may be broken.\')" /></td>
				</tr>
				<tr class="alt_row last">
					<td class="first"><label for="cookiepath">Cookie Çerez Yolu:</label></td>
					<td class="last alt_col"><input type="text" class="text_input" name="cookiepath" id="cookiepath" value="{6}" onkeyup="warnUser(this, \'This option was set automatically. Do not change it if you are not sure about the correct value, otherwise logging in or out on your forum may be broken.\')" onchange="warnUser(this, \'This option was set automatically. Do not change it if you are not sure about the correct value, otherwise logging in or out on your forum may be broken.\')" /></td>
				</tr>
				<tr>
					<th colspan="2" class="first last">İletişim Bilgileri</th>
				</tr>
				<tr class="last">
					<td class="first"><label for="contactemail">Contact Email:</label></td>
					<td class="last alt_col"><input type="text" class="text_input" name="contactemail" id="contactemail" value="{7}" /></td>
				</tr>
				<tr>
					<th colspan="2" class="first last">Security Settings</th>
				</tr>
				<tr class="last">
					<td class="first"><label for="acppin">ACP PIN:</label><br />Ayarlamak istemiyorsanız bu alanı boş bırakabilirsiniz/td>
					<td class="last alt_col"><input type="password" class="text_input" name="pin" id="acppin" value="" /></td>
				</tr>
				</tbody>
			</table>
		</div>

	<p>Kurulum işlemine devam edebilmek için İLERİ tuşuna basınız.</p>';

$l['config_step_error_config'] = '<div class="error">
<h3>Hata</h3>
<p>Aşağıdaki Hatalardan dolayı devam edilmemektedir.:</p>
{1}
<p>Lütfen üst kısımda belirtilen hataları düzeltip kuruluma devam ediniz..</p>
</div>';
$l['config_step_error_url'] = 'Forum URL\'sini girmediniz.';
$l['config_step_error_name'] = 'Forum adı belirtmediniz';
$l['config_step_revert'] = 'Bu ayarı orijinal değerine döndürmek için tıklayın.';


$l['admin_step_setupsettings'] = '<p>Temel forum ayarları başarıyla tamamlandı.</p>';
$l['admin_step_insertesettings'] = '<p>{2} ayar gurubuna, {1} adet yeni ayar eklendi.</p>
<p>Kullanıcı tanımlama ayarları eklendi.</p>';
$l['admin_step_insertedtasks'] = '<p>{1} adet zamanlanmış görev eklendi.</p>';
$l['admin_step_insertedviews'] = '<p>{1} adet admin hesabı oluşturuldu.</p>';
$l['admin_step_createadmin'] ='<p>Giriş yapabilmek ve forumu yönetebilmek için bir yönetici hesabı oluşturmanız gerekiyor.<br />Bu hesabı oluşturmak için lütfen aşağıdaki gerekli alanları doldurunuz.</p>';
$l['admin_step_admintable'] = '<div class="border_wrapper">
			<div class="title">Admin Hesap Bilgileri</div>

		<table class="general" cellspacing="0">
		<thead>
		<tr>
			<th colspan="2" class="first last">Hesap Bilgileri</th>
		</tr>
		</thead>
		<tr class="first">
			<td class="first"><label for="adminuser">Kullanıcı Adı:</label></td>
			<td class="alt_col last"><input type="text" class="text_input" name="adminuser" id="adminuser" value="{1}" /></td>
		</tr>
		<tr class="alt_row">
			<td class="first"><label for="adminpass">Şifre:</label></td>
			<td class="alt_col last"><input type="password" class="text_input" name="adminpass" id="adminpass" value="" autocomplete="off" onchange="comparePass()" /></td>
		</tr>
		<tr class="last">
			<td class="first"><label for="adminpass2">Şifre Tekrar:</label></td>
			<td class="alt_col last"><input type="password" class="text_input" name="adminpass2" id="adminpass2" value="" autocomplete="off" onchange="comparePass()"  /></td>
		</tr>
		<tr>
			<th colspan="2" class="first last">İletişim Bilgileri</th>
		</tr>
		<tr class="first last">
			<td class="first"><label for="adminemail">Email adresi:</label></td>
			<td class="alt_col last"><input type="text" class="text_input" name="adminemail" id="adminemail" value="{2}" /></td>
		</tr>
	</table>
	</div>

	<p>Kurulumda son Aşamaya geçmek için İLERİ tıklayın.</p>';

$l['admin_step_error_config'] = '<div class="error">
<h3>hata</h3>
<p>yBB kurulum sihirbazı, aşağıdaki hataları tespit etti:</p>
{1}
<p>Üsteki hataları düzeltip kurulum işlemine devam edebilirsiniz.</p>
</div>';
$l['admin_step_error_nouser'] = 'Kullanıcı adı girmediniz.';
$l['admin_step_error_nopassword'] = 'Şifre girmediniz.';
$l['admin_step_error_nomatch'] = 'Girmiş olduğunuz şifreler uyuşmuyor.';
$l['admin_step_error_noemail'] = 'İletişim için e-posta adresi girmediniz.';
$l['admin_step_nomatch'] = 'Yeniden yazılan parola ilk girişteki parola ile eşleşmiyor. Lütfen devam etmeden önce düzeltin.';

$l['done_step_usergroupsinserted'] = "<p>Kullanıcı grupları başarıyla oluşturuldu. ";
$l['done_step_admincreated'] = '<p>Admin hesabı başarıyla oluşturuldu. ';
$l['done_step_adminoptions'] = '<p>Yönetici izinleri başarıyla ayarlandı. ';
$l['done_step_cachebuilding'] = '<p>Cache verileri başarıyla yüklendi. ';
$l['done_step_success'] = '<p class="success">Tebrikler, MyBB forum kurulumunu başarıyla tamamladınız.</p>
<p><a href="http://mybb.com">MyBB Group</a>, tarafından kodlanan Yazılımı Tercih ettiğiniz için teşekkür ederiz. Türkçe Çeviri ve Türkçe Kurulum Paketi : <a href="http://www.onebe.net">ONEBE.NET</a></p>';
$l['done_step_locked'] = '<p>MyBB kurulum sihirbazı kilitlendi. Kurulum sihirbazını yeniden çalıştırabilmeniz için <b>install</b> klasöründeki \'lock\' dosyasını silmeniz gerekiyor.</p><p>Forumunuzu görüntülemek için <a href="../index.php">Buraya</a> , Admin paneline ulaşmak için <a href="../admin/index.php">Buraya</a> tıklayınız.</p>';
$l['done_step_dirdelete'] = '<p><strong><span style="colour:red">MyBB forumunuzu görüntüleyebilmek için <span style=\"font-size: 80%; color: maroon;\">(install)</span> klasörünü silmeniz veya adını değiştirmeniz gerekiyor.</span></strong></p>';
$l['done_whats_next'] = '<div class="error"><p><strong>Başka bir forum yazılımından geçiş yapmak mı istiyorsunuz ? </strong></p><p> MyBB Geçmek için sunduğu merge sistemi o kadar kolay ki linke tıklayarak  <a target="_blank" rel="noopener" href="https://mybb.com/download/merge-system">Merge Geçiş Sistemi</a> Daha fazla bilgi için.</p>';

/* UPGRADE LANGUAGE VARIABLES */
$l['upgrade'] = "MyBB Versiyon Yükseltme Sihirbazı";
$l['upgrade_welcome'] = "<p>MyBB {1} versiyon yükseltme sihirbazına hoşgeldiniz.</p><p>Versiyon yükseltme işlemine devam etmek için şu anda kullanmış olduğunuz versiyonu aşağıdaki seçeneklerden seçiniz.</p><p><strong>MyBB sürümünüzü yükseltmeden önce kesinlikle yedek almanızı öneriyoruz.</strong><br />Eğer herhangi bir hata ile karşılaşacak olursanız rahatlıkla yükseltme işlemini iptal edip, forumunuzu geri alabilirsiniz.<br />Bu işlem esnasında forumunuzun boyutuna göre sayfalarınızın yüklenmesi biraz zaman alabilir.</p><p>Eğer yedek aldıysanız ve versiyon yükseltme işlemine hazır olduğunuzu düşünüyorsanız, aşağıdaki seçeneklerden şu anda kullandığınız MyBB sürümünü seçerek <b>İleri</b> tuşuna tıklayınız.</p>";
$l['upgrade_templates_reverted'] = 'Şablonların Kontrolü Başarıyla Tamamlandı.';
$l['upgrade_templates_reverted_success'] = "<p>Şablonlarınızın güncelleme işlemi başarıyla tamamlandı. Lütfen güncelleme işlemine devam edebilmek için <b>İleri</b> tuşuna tıklayınız.</p>";
$l['upgrade_settings_sync'] = 'Eşleşme Ayarları Başarıyla Tamamlandı.';
$l['upgrade_settings_sync_success'] = "<p>Forum ayarlarınız, MyBB\'nin son sürümüne başarıyla yükseltildi.</p><p>{2} ayar grubu ile {1} adet yeni ayar eklendi.</p><p>Güncelleme işlemine devam etmek için lütfen <b>İleri</b> tuşuna tıklayınız.</p>";
$l['upgrade_datacache_building'] = 'Veritabanı Başarılı olarak Yapılandırıldı.';
$l['upgrade_building_datacache'] = '<p>Önbellek ayarları yapılandırılıyor..';
$l['upgrade_continue'] = 'Lütfen <b>İleri</b> tuşuna tıklayınız.';
$l['upgrade_locked'] = "<p>Güncelleme sihirbazı kilitlendi. Güncelleme sihirbazını yeniden çalıştırabilmeniz için <b>install</b> klasöründeki \'lock\' dosyasını silmeniz gerekiyor.</p><p>Forumunuzu görüntülemek için <a href=\"../index.php\">Buraya</a>  Admin paneline ulaşmak için <a href=\"../admin/index.php\">Buraya</a> tıklayınız.</p>";
$l['upgrade_removedir'] = 'Yükseltme yaptığınız MyBB forumunuzu görüntülemeden önce, lütfen (install) klasörünü silin veya adını değiştiriniz.';
$l['upgrade_congrats'] = "<p>Tebrikler, forumunuz MyBB {1} sürümüne başarıyla yükseltildi.</p>{2}<p><strong>Günlelleme işleminden sonra yapmanız gerekenler?</strong></p><ul><li>Bu yükseltme işleminde şablonlarınız güncellenmiş olacağından, güncellenen ve daha önce özelleştirmiş olduğunuz şablonları bularak düzenleme veya orjinal haline çevirme işlemi yaparak, olası yaşayabileceğiniz sorunları çözebilirsiniz.</li></ul>";
$l['upgrade_template_reversion'] = "Şablonların Dönüştürülmesi Hakkında";
$l['upgrade_template_reversion_success'] = "<p>Gerekli tüm veritabanı tabloları başarıyla kurulup, güncelleme işlemi tamamlanmıştır.</p><p>Güncelleme işlemi kullanmış olduğunuz temaların şablonlarının orjinal haline dönmesine neden olabilir. Bu sebepten dolayı <b>İleri</b> tuşuna tıklamadan önce, lütfen gerekli tüm yedeklerinizi aldığınızdan emin olun.";
$l['upgrade_send_stats'] = "<p><input type=\"checkbox\" name=\"allow_anonymous_info\" value=\"1\" id=\"allow_anonymous\" checked=\"checked\" /> <label for=\"allow_anonymous\"> MyBB için sunucu özellikleriniz hakkında anonim istatistikler gönderilsin mi?</label> (<a href=\"https://docs.mybb.com/1.8/install/anonymous-statistics/\" style=\"color: #555;\" target=\"_blank\"><small>Hangi bilgiler gönderilir?</small></a>)</p>";

$l['please_login'] = "Lütfen Giriş Yapınız";
$l['login'] = "Giriş";
$l['login_desc'] = "Lütfen güncelleme işlemine başlamadan önce kullanıcı adı ve şifrenizi giriniz. Bu işlemi sadece forum yöneticisi, (süper admin) gerçekleştirebilir.";
$l['login_username'] = "Kullanıcı Adı";
$l['login_password'] = "Şifre";
$l['login_password_desc'] = "Şifreniz Büyük/Küçük Harf Duyarlı olsun lütfen";

/* Error messages */
$l['development_preview'] = "<div class=\"error\"><h2 class=\"fail\">Uyarı</h2><p>MyBB'nin bu sürümü bir geliştirme önizlemesidir ve yalnızca test amaçlı kullanılmalıdır. </p> <p> Bu sürüm için eklentiler ve tema geliştirme dışında resmi bir destek sağlanmayacaktır. Bu yükleme / yükseltme işlemine devam ederek bunu yapmak kendi sorumluluğunuzdadır.</p></div>";
$l['locked'] = 'MyBB kurulum sihirbazı kilitli. Kurulum sihirbazını yeniden çalıştırabilmeniz için <b>install</b> klasöründeki \'lock\' dosyasını silmeniz gerekiyor.';
$l['no_permision'] = "Bu işlemi gerçekleştirebilmeniz için gerekli izniniz yok. Versiyon güncelleme işlemi yapabilmeniz için (tam yetkili admin), Forum yöneticisi olmanız gerekiyor.<br />(Tam yetkili admin) olmak için ./inc/config.php dosyasında kullanıcı ıd numaranızın ekli olması gerekir.<br /><br />Çıkış yapmak için lütfen <a href=\"upgrade.php?action=logout&amp;logoutkey={1}\">Buraya</a> tıklayın.";
$l['no_theme_functions_file'] = 'Hiçbir tema işlevi dosyası bulunamadı. Tüm dosyaların düzgün yüklendiğinden emin olun.';

$l['task_versioncheck_ran'] = "Sürüm kontrolü görevi başarıyla çalıştırıldı.";
