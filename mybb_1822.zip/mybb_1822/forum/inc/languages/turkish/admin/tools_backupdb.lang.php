﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['database_backups'] = "Veritabanı Yedekleri";
$l['database_backups_desc'] = "Bu kısımdan, ./admin/backups klasöründe depolanan forumunuzun veritabanı yedeklerinin listesini görebilir ve indirebilirsiniz.";
$l['new_database_backup'] = "Yeni Veritabanı Yedeği Oluştur";
$l['new_backup'] = "Yeni Yedek Oluştur";
$l['new_backup_desc'] = "Bu kısımdan, forumunuzun yeni bir veritabanı yedeğini oluşturabilirsiniz.";
$l['backups'] = "Yedekler";
$l['existing_database_backups'] = "Oluşturulan Veritabanı Yedekleri";

$l['backup_saved_to'] = "Yedeğin Kaydedildiği Dizin :";
$l['download'] = "Direkt İndir";
$l['table_selection'] = "Tablo Seçimi";
$l['backup_options'] = "Yedekleme Seçenekleri";
$l['table_select_desc'] = "Hangi tabloların yedeğini alacağınızı, tekil ya da çoğul olarak buradan seçebilirsiniz.";
$l['select_all'] = "Tümünü Seç";
$l['deselect_all'] = "Tümünün Seçimini Kaldır";
$l['select_forum_tables'] = "Forum Tablolarını Seç";
$l['file_type'] = "Dosya Formatı Seçiniz:";
$l['file_type_desc'] = "Veritabanı yedeğinin oluşturulmasını istediğiniz dosya formatını seçiniz.";
$l['gzip_compressed'] = "GZIP (.gz) Sıkıştırılmış (önerilir)";
$l['plain_text'] = "SQL (.sql) Sıkıştırılmamış";
$l['save_method'] = "Kayıt Metodu Seçiniz:";
$l['save_method_desc'] = "Yedeğin kaydedileceği Metodu Seçiniz.";
$l['backup_directory'] = "Yedek (./admin/backups) Klasörüne Kaydedilsin";
$l['backup_contents'] = "Yedek İçeriğini Seçiniz:";
$l['backup_contents_desc'] = "Veritabanı yedeği için içerik yapısı bilgisi Seçiniz.";
$l['structure_and_data'] = "Yapı ve Veri (önerilir)";
$l['structure_only'] = "Sadece Yapı";
$l['data_only'] = "Sadece Veri";
$l['analyze_and_optimize'] = "Analiz ve Optimize:";
$l['analyze_and_optimize_desc'] = "Veritabanı oluşturulurken seçilen Tablolar, Analiz ve Optimize edilsin mi?";
$l['perform_backup'] = "Yedeği Oluştur";
$l['backup_filename'] = "Dosya İsmi";
$l['file_size'] = "Dosya Boyutu";
$l['creation_date'] = "Oluşturulma Tarihi";
$l['no_backups'] = "Şu an oluşturulmuş herhangi bir yedek mevcut değil.";

$l['error_file_not_specified'] = "İndirmek için herhangi bir veritabanı yedeğini seçmediniz.";
$l['error_invalid_backup'] = "Seçtiğiniz yedek dosyası ya geçersiz ya da mevcut değil.";
$l['error_backup_doesnt_exist'] = "Belirtilen yedek mevcut değil.";
$l['error_backup_not_deleted'] = "Yedek silinemedi.";
$l['error_tables_not_selected'] = "Yedek alımı için bir tablo seçmediniz.";
$l['error_no_zlib'] = "Sitenizin barındığı sunucuda PHP için Zlib kütüphanesinin aktif/kurulu olmadığı algılandı. Bu sebepten dolayı GZIP (.gz) Sıkıştırılmış veritabanı yedeği oluşturamazsınız.";

$l['alert_not_writable'] = "Yedek klasörünüzün (./admin/backups) yazılabilir olmadığı algılandı. Bu sebepten dolayı yedek kaydedemezsiniz. Yazılabilir olması için (Chmod: 777) Yapınız";

$l['confirm_backup_deletion'] = "Bu yedeği silmek istediğinizden emin misiniz?";

$l['success_backup_deleted'] = "Yedek başarılı olarak silindi.";
$l['success_backup_created'] = "Yedek başarılı olarak oluşturuldu.";

