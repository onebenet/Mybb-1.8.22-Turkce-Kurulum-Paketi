﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['post_icons'] = "Başlık Sembolleri";
$l['add_post_icon'] = "Yeni Sembol Ekle";
$l['add_post_icon_desc'] = "Bu Kısımdan Yeni Bir Başlık Sembolü Ekleyebilirsiniz.";
$l['add_multiple_post_icons'] = "Çoklu Sembol Ekle";
$l['add_multiple_post_icons_desc'] = "Bu Kısımdan Çoklu Bir Şekilde Yeni Başlık Sembolleri Ekleyebilirsiniz.";
$l['edit_post_icon'] = "Sembol Düzenle";
$l['edit_post_icon_desc'] = "Bu Kısımdan Mevcut,Başlık Sembollerini Düzenleyebilirsiniz.";
$l['manage_post_icons'] = "Sembolleri Yönet";
$l['manage_post_icons_desc'] = "Bu Kısımdan Başlık Sembollerini, Düzenleyebilir, Silebilir ve Yönetebilirsiniz.";

$l['name_desc'] = "Bu Başlık Sembolü için Bir İsim Giriniz.";
$l['image_path'] = "Resim Yolu";
$l['image_path_desc'] = "Bu Başlık Sembolü için Resim Yolunu Giriniz. Temalar için farklı alanlarda başlık sembollerini kullanmak istiyorsanız eğer, <strong>{theme}</strong> resim dizini kısa yol kodunu kullanabilirsiniz.";
$l['save_post_icon'] = "Sembolü Kaydet";
$l['reset'] = "Sıfırla";

$l['path_to_images'] = "Resim Yolu";
$l['path_to_images_desc'] = "Çoklu Olarak Eklemek İstediğiniz Başlık Sembolleri için Resim Yolunu Giriniz.";
$l['show_post_icons'] = "Sembolleri Göster";
$l['image'] = "Resimler";
$l['add'] = "Eklensin mi?";
$l['save_post_icons'] = "Seçilen Sembolleri Kaydet";

$l['no_post_icons'] = "Şu an Forumunuza Eklenmiş Herhangi Bir Başlık Sembolü Bulunamadı.";

$l['error_missing_name'] = "Bu Başlık Sembolü için Bir İsim Belirtmediniz.";
$l['error_missing_path'] = "Bu Başlık Sembolü için Bir Resim Yolu Belirtmediniz.";
$l['error_missing_path_multiple'] = "Bu Başlık Sembolü için Bir Resim Yolu Girmediniz.";
$l['error_invalid_path'] = "Girmiş Olduğunuz Resim Yolu Geçersizdir.";
$l['error_no_images'] = "Belirtmiş Olduğunuz Resim Klasöründe Herhangi Bir Başlık Sembolü Bulunamadı veya Belirtilen Klasördeki Semboller Daha Önce Eklenmiş Olabilir.";
$l['error_none_included'] = "Eklemek için Herhangi Bir Sembol Seçmediniz.";
$l['error_invalid_post_icon'] = "Belirtmiş Olduğunuz Başlık Sembolü Mevcut Değil.";

$l['success_post_icon_added'] = "Başlık Sembolü Başarılı Olarak Eklendi.";
$l['success_post_icons_added'] = "Seçmiş Olduğunuz Başlık Sembolleri Başarılı Olarak Eklendi.";
$l['success_post_icon_updated'] = "Başlık Sembolü Başarılı Olarak Güncellendi.";
$l['success_post_icon_deleted'] = "Belirtmiş Olduğunuz Başlık Sembolü Başarılı Olarak Silindi.";

$l['confirm_post_icon_deletion'] = "Bu Başlık Sembolünü Silmek İstediğinizden Emin Misiniz?";
