﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
  * MyBB 1.8.22 Türkçe Dil Paketi * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['custom_profile_fields'] = "Özel Profil Alanları";
$l['custom_profile_fields_desc'] = "Bu Kısımdan, Özel Profil Alanlarını Düzenleyebilir, Silebilir veya Yönetebilirsiniz.";
$l['add_profile_field'] = "Profil Alanı Ekle";
$l['add_new_profile_field'] = "Yeni Profil Alanı Ekle";
$l['add_new_profile_field_desc'] = "Bu Kısımdan Yeni Bir Özel Profil Alanı Ekleyebilirsiniz.";
$l['edit_profile_field'] = "Profil Alanı Düzenle";
$l['edit_profile_field_desc'] = "Bu Kısımdan Özel Profil Alanlanını Düzenleyebilirsiniz.";

$l['title'] = "Profil Başlığı";
$l['short_description'] = "Kısa Bilgi";
$l['maximum_length'] = "Maksimum Uzunluk";
$l['maximum_length_desc'] = "Metin Alanları ve Metin Kutuları İçin Girilebilecek En Fazla Karakter Sayısını Belirtiniz.";
$l['field_length'] = "Alan Uzunluğu";
$l['field_length_desc'] = "Bu Alan Uzunluğu Sadece Tekli ve Çoklu Seçim Kutuları için Kullanılır.";
$l['display_order'] = "Görüntülenme Sırası";
$l['display_order_desc'] = "Bu Gösterim Sırası Diğer Profil Alanlarından Ayrıştırmak için Kullanılır. Belirteceğiniz Gösterim Sırası Diğer Profil Alanlarından Farklı Olmalıdır.";
$l['text'] = "Text Kutusu";
$l['textarea'] = "Text Alanı";
$l['select'] = "Kutu Seç";
$l['multiselect'] = "Çoklu Seçim Kutuları";
$l['radio'] = "Radyo Butonu";
$l['checkbox'] = "İşaretlemeli Kutular";
$l['field_type'] = "Alan Seçenekleri";
$l['field_type_desc'] = "Gösterilmesini İstediğiniz Alan Türünü Seçmenizi Sağlar.";
$l['field_regex'] = "Düzenli İfade (Regex):";
$l['field_regex_desc'] = "Kullanıcı Girişleri ile Uyumlu Normal Bir İfade Giriniz. Eğer, Emin Değil İseniz Bu Alanı Boş Bırakınız. Bu Alan için Girişlerde Güvenlik Doğrulaması Yapılmaz.<br />
<strong>Örnek:</strong> ([a-z0-9_\- ,.+]+)";
$l['selectable_options'] = "Seçilebilir Alanlar?";
$l['selectable_options_desc'] = "Lütfen, Her Bir Seçeneği Ayrı Bir Satırda Giriniz. Bu Sadece <b>Seçim kutuları, İşaretleme Kutuları ve Radyo Buton</b> Türlerinde Geçerlidir.";
$l['required'] = "Gerekli?";
$l['required_desc'] = "Bu Profil Alanı, ''Kayıt Sayfası'' ve ''Profil Bilgilerini Düzenleme'' Kısmında Gerekli/Zorunlu Alan Olarak Gösterilsin mi?<br /><strong>Not:</strong> Eğer, Bu alan Gizli veya Düzenlenebilir Değil İse Geçerli Olmayacaktır.";
$l['show_on_registration'] = "Kayıt Sayfasında Gösterilsin Mi?";
$l['show_on_registration_desc'] = "Bu profil alanının, (kayıt) sayfasında gösterilmesini istiyor musunuz?<br /><strong>Not:</strong> Eğer bu alan düzenlenebilir değil ise geçerli olmayacaktır. Geçerli olması için düzenlenebilir alan olması gerekli. Ayrıca her zaman kayıt sayfasında gerekli/zorunlu alanlar kısmında görünecektir.";
$l['display_on_profile'] = "Profil Sayfasında Gösterilsin Mi?";
$l['display_on_profile_desc'] = "Bu profil alanının, kullanıcıların (profil) sayfalarında gösterilmesini istiyor musunuz? Bu ayar, Forum yöneticileri için geçerli değildir.";
$l['display_on_postbit'] = "Postbitte Gösterilsin Mi?";
$l['display_on_postbit_desc'] = "Bu profil alanının, kullanıcının konu ve yorumlarında (postbit) gösterilmesini istiyor musunuz?";
$l['viewableby'] = 'Görüntüleme İzinleri:';
$l['viewableby_desc'] = 'Bu Profil Alanını Görütüleyebilecek Kullanıcı Gruplarını Seçiniz.';
$l['editableby'] = 'Düzenleme İzinleri:';
$l['editableby_desc'] = 'Bu Profil Alanını Düzenleyebilecek Kullanıcı Gruplarını Seçiniz.';
$l['min_posts_enabled'] = "Minimum Mesaj Sayısı?";
$l['min_posts_enabled_desc'] = "Bu alanı belirleyeceğiniz mesaj sayısına ulaşmış kişiler için ayarlamak/uygulamak istiyorsanız eğer aşağıdaki metin kutusuna mesaj limitini giriniz. (Devre dışı olması için boş bırakınız.)";
$l['parser_options'] = "Ayrıcalık Seçenekleri:";
$l['parse_allowhtml'] = "Bu profil alanı için [HTML] kod kullanımına izin verilsin mi?";
$l['parse_allowmycode'] = "Bu profil alanı için [Mykod] kullanımına izin verilsin mi?";
$l['parse_allowsmilies'] = "Bu profil alanı için (İfade) kullanımına izin verilsin mi?";
$l['parse_allowimgcode'] = "Bu profil alanı için [İMG] tagı kullanımına izin verilsin mi?";
$l['parse_allowvideocode'] = "Bu profil alanı için [Video] tagı kullanımına izin verilsin mi?";
$l['save_profile_field'] = "Profil Alanını Kaydet";
$l['name'] = "Mevcut Özel Profil Alanları";
$l['registration'] = "Kayıtta?";
$l['editable'] = "Düzenlenebilir?";
$l['profile'] = "Profilde?";
$l['postbit'] = "Postbitte?";
$l['edit_field'] = "Bu Alanı Düzenle";
$l['delete_field'] = "Bu Alanı Sil";
$l['no_profile_fields'] = "Şu anda Forumunuzda Kayıtlı Herhangi Bir Özel Profil Alanı Bulunamadı.";

$l['error_missing_name'] = "Özel Profil Alanı İçin Bir Başlık Belirtmediniz.";
$l['error_missing_description'] = "Özel Profil Alanı İçin Kısa Bir Bilgi Belirtmediniz.";
$l['error_invalid_fid'] = "Seçmiş Olduğunuz Özel Profil Alanı Bulunamadı.";

$l['success_profile_field_added'] = "Özel Profil Alanı Başarılı Olarak Oluşturuldu.";
$l['success_profile_field_saved'] = "Özel Profil Alanı Başarılı Olarak Kaydedildi.";
$l['success_profile_field_deleted'] = "Özel Profil Alanı Başarılı Olarak Silindi.";

$l['confirm_profile_field_deletion'] = "Bu Özel Profil Alanını Silmek İstediğinizden Emin Misiniz?";
