﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['home'] = "Başlangıç";

$l['dashboard'] = "<img src=\"../images/admincp/anasayfa.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Başlangıç";
$l['preferences'] = "<img src=\"../images/admincp/ayar.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Admin KP Tercihleri";
$l['mybb_credits'] = "<img src=\"../images/admincp/mybb.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> MyBB Hakkında";

$l['add_new_forum'] = "<img src=\"../images/admincp/forum.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Yeni Forum Ekle";
$l['search_for_users'] = "<img src=\"../images/admincp/arama.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Kullanıcı Arama";
$l['themes'] = "<img src=\"../images/admincp/tema.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Temalar";
$l['templates'] = "<img src=\"../images/admincp/sablon.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Şablonlar";
$l['plugins'] = "<img src=\"../images/admincp/eklenti.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Pluginler";
$l['database_backups'] = "<img src=\"../images/admincp/ayar.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Veritabanı Yedekleri";
$l['quick_access'] = "Hızlı Erişim";
$l['online_admins'] = "Çevrimiçi Yöneticiler";
$l['ipaddress'] = "IP Adresi:";
$l['mybb_documentation'] = "<img src=\"../images/admincp/belgeler.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> MyBB Dökümanları";

