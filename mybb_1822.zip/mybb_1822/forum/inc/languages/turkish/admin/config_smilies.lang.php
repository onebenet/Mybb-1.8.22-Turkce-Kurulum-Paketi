﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['smilies'] = "İfadeler";
$l['manage_smilies'] = "İfadeleri Yönet";
$l['manage_smilies_desc'] = "Bu kısımdan, forumunuz için mevcut olan ifadeleri düzenleyebilir veya siliebilirsiniz.";
$l['add_smilie'] = "Yeni İfade Ekle";
$l['add_smilie_desc'] = "Bu Kısımdan, forumunuz için yeni bir ifade ekleyebilirsiniz.";
$l['add_multiple_smilies'] = "Çoklu İfade Ekle";
$l['add_multiple_smilies_desc'] = "Bu Kısımdan, forumunuz için çoklu olarak ifade ekleyebilirsiniz.";
$l['edit_smilie'] = "İfade Düzenle";
$l['edit_smilie_desc'] = "Bu Kısımdan, seçmiş olduğunuz ifadeyi düzenleyebilirsiniz.";
$l['mass_edit'] = "Çoklu Düzenleme";
$l['mass_edit_desc'] = "Bu Kısımdan tek bir işlem sayesinde tüm ifadeleri düzenleyebilirsiniz.";

$l['no_smilies'] = "Şu an forumunuza yüklü hiçbir ifade mevcut değil.";

$l['image'] = "Resim";
$l['name'] = "İsim";
$l['text_replace'] = "Kısaltma Kodu";
$l['text_replace_desc'] = "Bu ayar, ifade için yerine gösterilecek olan (kısa yol ismi) belirlemenizi sağlar.";
$l['image_path'] = "Resim Yolu URL";
$l['image_path_desc'] = "Bu ayar, ifade resmi için resmin yolunu belirlemenizi sağlar. Temalar için farklı alanlarda ifadeleri kullanmak istiyorsanız eğer, <strong>{theme}</strong> resim dizini kısa yol kodunu kullanabilirsiniz.";
$l['order'] = "Sıra";
$l['display_order'] = "Gösterim Sırası";
$l['display_order_desc'] = "Bu ayar, ifadelerin sıralama şeklini düzenlemenize olanak sağlar.";
$l['mass_edit_show_clickable'] = "Tıklanabilir Mi?";
$l['show_clickable'] = "Tıklanabilir İfade Listesinde Gösterilsin Mi?";
$l['show_clickable_desc'] = "Bu ayar, ifadelerin metin edötüründe ve yanındaki ifade listesinde tıklanabilir olarak seçilmesine/gösterilmesine olanak sağlar.";
$l['include'] = "Ekle?";
$l['path_to_images'] = "Resim Klasörünün Yolu?";
$l['path_to_images_desc'] = "Bu ayar ifadelerin bulunduğu klasörün yolunu belirlemenize olanak sağlar.";
$l['smilie_delete'] = "Sil?";
$l['save_smilie'] = "İfadeyi Kaydet";
$l['save_smilies'] = "İfadeleri Kaydet";
$l['show_smilies'] = "İfadeleri Göster";
$l['reset'] = "Yenile";

$l['error_missing_name'] = "Bu ifade için bir isim belirtmediniz.";
$l['error_missing_text_replacement'] = "Bu ifade için resim yerine gösterilecek <b>''Kısaltma Kodu''</b> terimini belirtmediniz.";
$l['error_missing_path'] = "Bu ifade için resim yolunu belirtmediniz.";
$l['error_missing_path_multiple'] = "Çoklu ifade yüklemek için bir resim klasörü yolu belirtmediniz.";
$l['error_missing_order'] = "Bu ifade için gösterim sırasını belirtmediniz.";

$l['error_duplicate_order'] = "Bu ifade-(ler) için geçerli bir listeleme sırası girmediniz.";
$l['error_missing_clickable'] = "<b>Tıklanabilir İfade Listesinde Gösterilsin Mi?</b> seçeneğinde herhangi bir seçim yapmadınız.";

$l['error_no_smilies'] = "Belirtmiş olduğunuz klasörde, ya hiç ifade resmi yok, yada daha önce yüklenmiş ifadeleri, yüklemeye çalışıyorsunuz.";
$l['error_no_images'] = "Belirtmiş olduğunuz resim klasöründe hiçbir ifade bulunamadı.";
$l['error_none_included'] = "Yüklenecek her hangi bir ifade belirtmediniz.";
$l['error_invalid_path'] = "Gerçerli bir resim Yolu belirtmediniz.";
$l['error_invalid_smilie'] = "Belirtmiş olduğunuz ifade mevcut değil.";

$l['success_smilie_added'] = "İfade başarılı olarak oluşturuldu.";
$l['success_multiple_smilies_added'] = "Seçmiş olduğunuz ifadeler başarılı olarak yüklendi.";
$l['success_smilie_updated'] = "İfade başarılı olarak güncellendi.";
$l['success_multiple_smilies_updated'] = "Tüm ifadeler başarılı olarak güncellendi.";
$l['success_smilie_deleted'] = "Belirtmiş olduğunuz ifade başarılı olarak silindi.";
$l['success_mass_edit_updated'] = "Tüm ifadeler başarılı olarak güncellendi.";

$l['confirm_smilie_deletion'] = "Bu İfadeyi Silmek İstediğinize Emin Misiniz?";

