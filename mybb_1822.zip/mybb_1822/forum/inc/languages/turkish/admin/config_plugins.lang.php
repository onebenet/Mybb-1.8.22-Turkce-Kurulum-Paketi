﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['plugins'] = "Eklenti Yönetimi";
$l['plugins_desc'] = "Bu Kısımdan Forumunuz için <b>./inc/plugins</b> Klasörüne Yüklemiş Olduğunuz Eklentileri Aktif veya Pasif Konumuna Getirebilir yada Yönetebilirsiniz.<br />Aktif Eklentilerinizin Veritabanına İşlenen Bilgilerinin Silinmemesi için O eklentiyi Kaldırmak Yerine Pasif Durumuna Getirebilirsiniz, Bu Durumunda Eklentinizi Yeniden Yapılandırmak Zorunda Kalmazsınız.";
$l['plugin_updates'] = "Eklenti Güncellemeleri";
$l['plugin_updates_desc'] = "Bu Kısımdan Forumunuzda Yüklü Olan Tüm Eklentilerinizin, Güncel Olup Olmadıklarını Kontrol Etmenize Olanak Sağlar. Bu Sayede Kullanmış Olduğunuz Bir Eklentinin Yeni Bir Versiyonunun Olup Olmadığını Öğrenebilirsiniz.";
$l['browse_plugins'] = "Top 10 Eklenti";
$l['browse_plugins_desc'] = "Bu Kısımda, En Popüler ve En Çok Kullanılan Eklentilerin, güncel Versiyonlarının İndirilebilir Bir Listesini Görüntüleyebilirsiniz.<br />Daha Fazla Eklenti için Sağ Taraftaki Arama Kutusunun Altında Bulunan, <b>(Tüm Eklentileri Göster)</b> Sekmesine Tıklamanız Yeterlidir.";
$l['browse_all_plugins'] = "Tüm Eklentileri Göster";

$l['plugin'] = "Eklenti Listesi";
$l['active_plugin'] = "Aktif Eklentiler";
$l['inactive_plugin'] = "Pasif Eklentiler";
$l['your_version'] = "Kullandığınız Versiyon";
$l['latest_version'] = "Son Versiyon";
$l['download'] = "İndir";
$l['deactivate'] = "Eklentiyi Pasifleştir";
$l['activate'] = "Eklentiyi Aktifleştir";
$l['install_and_activate'] = "Eklentiyi Kur &amp; Aktifleştir";
$l['uninstall'] = "Eklentiyi Kaldır";
$l['created_by'] = "Eklenti Yapımcısı: ";
$l['no_plugins'] = "Şu an Forumunuza Yüklü Herhangi Bir Eklenti Bulunamadı.";
$l['no_active_plugins'] = "Şu anda Aktif durumda hiçbir eklenti mevcut değil.";
$l['no_inactive_plugins'] = "Şu anda Pasif durumda hiçbir eklenti mevcut değil.";

$l['plugin_incompatible'] = "Yüklemeye Çalıştığınız Bu Eklenti MyBB {1} Versiyonu ile Uyumlu Değildir.";

$l['recommended_plugins_for_mybb'] = "MyBB {1} , Versiyonuna Ait En Popüler Eklentilerin Listesi";
$l['browse_results_for_mybb'] = "MyBB {1} Versiyonu için Eklenti Arama Sonuçları";
$l['search_for_plugins'] = "Eklenti Ara";
$l['search'] = "Arama";

$l['error_vcheck_no_supported_plugins'] = "Forumunuzdaki Yüklü Eklentiler Sürüm Kontrolü Tarafından Desteklenmiyor.";
$l['error_vcheck_communications_problem'] = "Versiyon Kontrolü Yapılırken,Sunucu ile Bağlantı Sorunu Oluştu. Lütfen Daha Sonra Tekrar Deneyiniz.";
$l['error_vcheck_vulnerable'] = "[Güvenlik Riskli Eklenti]:";
$l['error_vcheck_vulnerable_notes'] = "Bu eklenti MyBB personeli tarafından güvenlik riski yüksek olarak işaretlenmiştir. Güvenliğiniz gereği bu eklentiyi sistemden tamamen silmeniz/kaldırmanız önemle tavsiye edilir. Lütfen, güvenlik riski notlarını inceleyiniz: ";
$l['error_no_input'] = "<img src=\"images/icons/uyari.gif\" alt=\"Hata\" height=\"14\" width=\"14\" /> Hata Kodu 1: Giriş Belirlenmedi.";
$l['error_no_pids'] = "<img src=\"images/icons/uyari.gif\" alt=\"Hata\" height=\"14\" width=\"14\" /> Hata Kodu 2: Eklenti id'si Belirlenmedi.";
$l['error_communication_problem'] = "Versiyon Kontrolü Yapılırken,Sunucu ile Bağlantı Sorunu Oluştu. Lütfen Daha Sonra Tekrar Deneyiniz.";
$l['error_invalid_plugin'] = "Belirtmiş Olduğunuz Eklenti Bulunamadı.";
$l['error_no_results_found'] = "Belirtmiş Olduğunuz Kelimeye Göre Hiçbir Sonuç Bulunmadı.";

$l['success_plugins_up_to_date'] = "Tebrikler, Tüm Eklentileriniz Güncel Durumda. :)";
$l['success_plugin_activated'] = "Belirtmiş Olduğunuz Eklenti Başarılı Olarak Aktifleştirildi.";
$l['success_plugin_deactivated'] = "Belirtmiş Olduğunuz Eklenti Başarılı Olarak Pasifleştirildi.";
$l['success_plugin_installed'] = "Belirtmiş Olduğunuz Eklenti Başarılı Olarak Kuruldu & Aktifleştirildi.";
$l['success_plugin_uninstalled'] = "Belirtmiş Olduğunuz Eklenti Başarılı Olarak Kaldırıldı.";
