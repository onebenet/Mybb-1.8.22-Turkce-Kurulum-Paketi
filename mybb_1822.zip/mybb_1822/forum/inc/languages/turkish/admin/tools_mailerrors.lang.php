﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['system_email_log'] = "Sistem E-Posta Hata Kayıtları";
$l['system_email_log_desc'] = "Bu kısımdan, Gönderilen E-Postaların hata kayıtları ve sebeplerini görebilirsiniz.<br />Aynı zamanda Bu bölüm, SMTP yapılandırma sorunlarını tanımlamak için ya da sunucu üzerindeki Posta desteğinin var olup olmadığı tanımlamak için özellikle yararlıdır.";
$l['prune_system_email_log'] = "Sistem E-Posta Kayıtlarını Ayıkla";
$l['filter_system_email_log'] = "Sistem E-Posta Kayıtlarını Filtrele";

$l['close_window'] = "Pencereyi Kapat";
$l['user_email_log_viewer'] = "Kullanıcı E-Posta Kaydı Takipcisi";
$l['smtp_code'] = "SMTP Kodu:";
$l['smtp_server_response'] = "SMTP Sunucu Yanıtı:";
$l['to'] = "Kime";
$l['from'] = "Kimden";
$l['subject'] = "Konu";
$l['date'] = "Tarih";
$l['email'] = "E-Posta";
$l['date_sent'] = "Gönderilme Tarihi";
$l['error_message'] = "Hata Mesajı";
$l['fine'] = "Ara/Bul";
$l['no_logs'] = "Şu anda herhangi bir E-Posta hatası kaydı bulunmamaktadır.";
$l['subject_contains'] = "E-Posta Başlığı";
$l['error_message_contains'] = "Hata Mesajı";
$l['to_address_contains'] = "Kime Gönderilmiş";
$l['from_address_contains'] = "Kimden Gönderilmiş";
$l['find_emails_to_addr'] = "Bu adrese gönderilmiş olan tüm e-posta kayıtlarını bul";

