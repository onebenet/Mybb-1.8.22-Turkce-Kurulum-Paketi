﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['warning_logs'] = "Uyarı Kayıtları";
$l['warning_logs_desc'] = "Bu kısımdan, kullanıcılara verilen uyarıların geçmişine bakabilirsiniz.";
$l['warned_user'] = "Kullanıcı Adı";
$l['warning'] = "Uyarı Sebebi & Seviyesi";
$l['date_issued'] = "Uyarı Tarihi";
$l['expires'] = "Bitiş Tarihi";
$l['expiry_date'] = "Bitiş Tarihi";
$l['issued_date'] = "Uyarı Tarihi";
$l['issued_by'] = "Uyaran Kullanıcı";
$l['details'] = "Detaylar";
$l['filter_warning_logs'] = "Kullanıcı Kayıtları Filtrele";
$l['filter_warned_user'] = "Uyarılan kullanıcı:";
$l['filter_issued_by'] = "Uyaran Kullanıcı:";
$l['filter_reason'] = "Uyarı Sebebi:";
$l['sort_by'] = "Listeleme Metodu Seç:";
$l['results_per_page'] = "Sayfa Başına Gösterilecek Sonuç:";
$l['view'] = "Görüntüle";
$l['no_warning_logs'] = "Gösterilecek uyarı kaydı yok.";
$l['revoked'] = "İptal Edildi:";
$l['post'] = "Mesaj";

$l['asc'] = "Artan";
$l['desc'] = "Azalan";

$l['in'] = "-";
$l['order'] = "";

$l['warning_details'] = "Uyarı Detayları";
$l['warning_note'] = "Yönetici Notu:";
$l['already_expired'] = "Sona Ermiş";
$l['warning_revoked'] = "İptal Edilmiş";
$l['warning_active'] = "Aktif";
$l['error_invalid_warning'] = "Geçersiz bir uyarı belirtildi.";

$l['revoke_warning'] = "Bu Uyarıyı İptal Et";
$l['revoke_warning_desc'] = "Bu uyarıyı iptal etmek için lütfen, aşağıya sebep giriniz. Bu uyarı tarafından maruz kalınan hiç bir yasak ya da süspansiyon kaldırılmayacaktır.";
$l['reason'] = "Sebep:";
$l['warning_is_revoked'] = "Bu uyarı iptal edildi.";
$l['revoked_by'] = "İptal Eden:";
$l['date_revoked'] = "İptal Tarihi:";
$l['error_already_revoked'] = "Bu uyarı zaten iptal edildi.";
$l['error_no_revoke_reason'] = "Bu uyarıyı neden iptal ettiğinizi girmediniz.";
$l['redirect_warning_revoked'] = "Bu uyarı iptal edildi ve kullanıcının uyarı seviyesi başarıyla azaltıldı.";
