﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['users_and_groups'] = "Üyeler &amp; Gruplar";

$l['users'] = "<img src=\"../images/admincp/uyeler.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Üyeler";
$l['groups'] = "<img src=\"../images/admincp/gruplar.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Gruplar";
$l['user_titles'] = "<img src=\"../images/admincp/kullanici-b.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\"  border=\"0\"> Kullanıcı Başlıkları";
$l['banning'] = "<img src=\"../images/admincp/ban.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Üye Yasaklama";
$l['admin_permissions'] = "<img src=\"../images/admincp/admin.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\"  border=\"0\"> Admin Yetkileri";
$l['mass_mail'] = "<img src=\"../images/admincp/t-posta.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Toplu E-Posta Sistemi";
$l['group_promotions'] = "<img src=\"../images/admincp/t-gruplar.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Terfi Grupları";

$l['can_manage_users'] = "Üyeleri Yönetebilir Mi?";
$l['can_manage_user_groups'] = "Kullanıcı Gruplarını Yönetebilir Mi?";
$l['can_manage_user_titles'] = "Kullanıcı Başlıklarını Yönetebilir Mi?";
$l['can_manage_user_bans'] = "Kullanıcı Yasaklamayı Yönetebilir Mi?";
$l['can_manage_admin_permissions'] = "Admin Yetkilerini Yönetebilir Mi?";
$l['can_send_mass_mail'] = "Toplu E-Posta Gönderebilir Mi?";
$l['can_manage_group_promotions'] = "Terfi Gruplarını Yönetebilir Mi?";

