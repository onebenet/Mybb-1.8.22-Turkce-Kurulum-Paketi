﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['statistics'] = "Forum İstatistikleri";
$l['overall_statistics'] = "Genel Forum İstatistikleri";
$l['overall_statistics_desc'] = "Bı kısımdan, Genel forum istatistiklerini, <strong>UTC</strong> zaman formatına göre görüntüleyebilirsiniz.";

$l['date_range'] = "Tarih Formatı";

$l['date'] = "Tarih";
$l['users'] = "Kullanıcılar";
$l['threads'] = "Konular";
$l['posts'] = "Yorumlar";

$l['from'] = "";
$l['to'] = "ile";

$l['increase'] = "Artan";
$l['no_change'] = "Hareket Yok";
$l['decrease'] = "Azalan";

$l['error_no_results_found_for_criteria'] = "Belirtmiş olduğunuz zaman aralığında herhangi bir kayıt bulunamadı. Lütfen, farklı bir zaman birimi giriniz.";
$l['error_no_statistics_available_yet'] = "Üzgünüz, Şu anda forumunuz için kaydadeğer herhangi bir kayıt bulunamadı.";
