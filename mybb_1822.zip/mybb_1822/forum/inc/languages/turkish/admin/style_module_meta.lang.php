﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['templates_and_style'] = "Temalar & Şablonlar";

$l['themes'] = "<img src=\"../images/admincp/tema.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Temalar";
$l['templates'] = "<img src=\"../images/admincp/sablon.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Şablonlar";

$l['can_manage_themes'] = "Temaları Yönetebilir Mi?";
$l['can_manage_templates'] = "Şablonları Yönetebilir Mi?";

