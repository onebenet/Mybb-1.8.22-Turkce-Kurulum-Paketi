﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['dashboard'] = "Genel Bakış";
$l['dashboard_description'] = "Bu kısımda, forumunuzla ilgili çeşitli istatistikleri görebilirsiniz. Ayrıca diğer yöneticilerin de görebileceği notlar bırakabilirsiniz.";
$l['mybb_server_stats'] = "MyBB ve Sunucu İstatistikleri";
$l['forum_stats'] = "Forum İstatistikleri";
$l['mybb_version'] = "MyBB Versiyonunuz";
$l['threads'] = "Konular";
$l['new_today'] = "Bugün Gönderilenler";
$l['unapproved'] = "Onaylanmamış";
$l['php_version'] = "PHP Versiyonunuz";
$l['posts'] = "Yorumlar";
$l['sql_engine'] = "MySQL Versiyonunuz";
$l['users'] = "Kullanıcılar";
$l['registered_users'] = "Kayıtlı Kullanıcı";
$l['active_users'] = "Aktif Kullanıcı";
$l['registrations_today'] = "Bugün Kayıt Olan Kullanıcı";
$l['awaiting_activation'] = "Aktifleştirme Bekleyen";
$l['server_load'] = "Sunucu Yüklenmesi";
$l['attachments'] = "Ekli Dosyalar";
$l['used'] = "Kullanılan Alan";
$l['reported_posts'] = "Rapor Edilen Mesaj";
$l['unread_reports'] = "Okunmamış Rapor";

$l['version_check'] = "Versiyon Kontrol";
$l['last_update_check_two_weeks'] = "Son <a href=\"{1}\">MyBB Versiyon Kontrolü</a>nüz iki haftadan uzun süre önce yapılmış.";
$l['new_version_available'] = "Şu anda {1} sürümünü kullanıyorsunuz. Güncel MyBB Sürümü: {2}&nbsp;<img src=\"../images/icons/external_link.png\" alt=\"\" height=\"9\" width=\"9\">";

$l['version_check_description'] = "Bu kısımda, forumunuzda kullanmakta olduğunuz MyBB versiyonunuzu kontrol edebilir ve MyBB duyurularını direkt olarak takip edebilirsiniz.";
$l['latest_mybb_announcements'] = "Son MyBB Duyuruları";
$l['no_announcements'] = "Hiçbir duyuru mevcut değil. <a href=\"index.php?module=home&amp;action=version_check\">Duyuruları Güncelle/Kontrol Et</a>.";
$l['your_version'] = "Sizin Versiyonunuz";
$l['latest_version'] = "Son Versiyon";
$l['update_forum'] = "Lütfen versiyonunuzu gücellemek için <a href=\"http://mybb.com/\" target=\"_blank\">MyBB Download</a>&nbsp;<img src=\"../images/icons/external_link.png\" alt=\"\" height=\"9\" width=\"9\"> sayfasını ziyaret ederek, son ve güncel MyBB sürümünü yükleyiniz.";
$l['read_more'] = "Devamını Oku";

$l['success_up_to_date'] = "Tebrikler! Şu Anda MyBB'nin En Son Yayınlanan Sürümünü Kullanıyorsunuz.";

$l['error_out_of_date'] = "Kullandığınız MyBB Sürümü Güncel Değil!";
$l['error_communication'] = "Sürüm Kontrolü Yapılırken Bir Hata Oluştu. Lütfen, Birkaç Dakika Sonra Tekrar Deneyiniz.";
$l['error_fetch_news'] = "Sunucudaki bir sorundan dolayı, MyBB duyurularını görüntülemek için Resmi Destek Sitesinden başarıyla alınamıyor.";

$l['news_description'] = "En son haberler <a href=\"https://blog.mybb.com/\" target=\"_blank\" rel=\"noopener\">MyBB Blog</a> .";

$l['admin_notes_public'] = "Bu Notları Sadece, Admin Paneline Erişim İzni Olan Yöneticiler Görebilir.";
$l['admin_notes'] = "Yönetici Notları";
$l['save_notes'] = "Notları Kaydet/Güncelle";

$l['success_notes_updated'] = "Yönetici Notları Başarıyla Olarak Güncellendi.";
