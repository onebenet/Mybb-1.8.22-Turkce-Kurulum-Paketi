﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['preferences_and_personal_notes'] = "Tercihler ve Özel Notlar";
$l['prefs_and_personal_notes_description'] = "Bu kısımdan, Admin Kontrol Paneli tercihlerini yönetebilir ve kendiniz için özel notlar bırakabilirsiniz.";

$l['preferences'] = "Tercihler";
$l['global_preferences'] = "Genel Tercihler";
$l['acp_theme'] = "Admin KP Teması";
$l['select_acp_theme'] = "Lütfen, Admin Kontrol Panel Stilinizi seçiniz.";
$l['acp_language'] = "Admin KP Dili";
$l['select_acp_language'] = "Lütfen, Admin Kontrol Panel Dilini seçiniz.";
$l['notes_not_shared'] = "Bu Notlar Sadece, Size Özel Notlardır ve Diğer Yöneticiler Göremezler.";
$l['save_notes_and_prefs'] = "Özel Notları & Tercihleri Kaydet/Güncelle";
$l['personal_notes'] = "Özel Notlar";
$l['codemirror'] = "Şablonlar & Stiller için Kod Renklendirme Aktif Edilsin Mi?";
$l['use_codemirror_desc'] = "Bu özellik, (şablonlar ve stil sayfalarını düzenlemede sözdizimi vurgulamaları için kodların renkli gösterilmesini sağlar).<br />Aynı zamanda eğer, tarayıcılardan kaynaklı çeşitli sorunlar yaşıyorsanız ve/veya yavaş yüklenmeler ile karşılaşıyorsanız Kod Renklendirmeyi kapatmanıza/devre dışı bırakmanızada olanak sağlar.";

$l['success_preferences_updated'] = "Tercihler başarılı olarak güncellendi.";

$l['use_2fa_desc'] = "İki ''Faktörlü Kimlik Doğrulama'' yönetici hesabınız için güvenli bir yöntemdir.<br />Bu ayar aktif edildiğinde Admin Panele her girişte bir QR Kodu belirecektir.<br />Bu özelliği kullanabilmek için (Android, iOS, Windows Phone işletim sistemine sahip telefonlarda çalışabilen) <strong>Google Authenticator</strong> veya <strong>Authy</strong> gibi uygulamaları kulanabilirsiniz.<br />Ayrıntılı bilgi için <a href=\"https://docs.mybb.com/1.8/administration/security/2fa/\" target=\"_blank\">MyBB Wiki Sayfasını</a> ziyaret edebilir ve uygulama bağlantılarına erişebilirsiniz.";
$l['my2fa_qr'] = "2 Faktörlü Doğrulama Kodu";
$l['recovery_codes_desc'] = "<a href=\"index.php?module=home-preferences&amp;action=recovery_codes\">Kurtarma Kodlarını Görüntüle</a>.";
$l['recovery_codes'] = "Kurtarma Kodları";
$l['recovery_codes_warning'] = "<b>Not:</b> kodlar, her sayfa ziyaretinde rejenere edilerek ve sadece bir kez kullanılabilir.";
