﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 * MyBB 1.8.22 Türkçe Dil Paketi 
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['users'] = "Kullanıcılar";

$l['search_for_user'] = "Kullanıcı Adı Ara";
$l['browse_users'] = "Kullanıcılara Gözat";
$l['browse_users_desc'] = "Bu kısımda forumunuzda kayıtlı kullanıcılara farklı gösterimler ile gözatabilirsiniz.Farklı gösterimlerle gözatmanız özellikle farklı bilgiler ile farklı sonuçlar elde etmenizde elverişlidir.";
$l['find_users'] = "Kullanıcı Ara";
$l['find_users_desc'] = "Listede bulamadığınız kullanıcıları buradan bulabilirsiniz.Az alan doldurursanız daha geniş, çok alan doldurursanız daha dar arama sonuçları elde edersiniz.";
$l['create_user'] = "Yeni Kullanıcı Oluştur";
$l['create_user_desc'] = "Burada yeni bir kullanıcı oluşturabilirsiniz.";
$l['merge_users'] = "Kullanıcıları Birleştir";
$l['merge_users_desc'] = "Burada iki kullanıcı hesabını bir kullanıcıda birleştirebilirsiniz.\"Kaynak Hesap\" <strong>sadece</strong> \"Hedef Hesap\" kalacak şekilde birleştirilecektir. \"Kaynak Hesap\"ın mesajları, konuları, özel mesajları, takvim olayları, mesaj sayısı ve arkadaş listesi \"Hedef Hesap\"ta birleştirilecektir.<br /><span style=\"font-size: 15px;\">Lütfen bu işlemin geri alınamayacağını unutmayın.</span>";
$l['edit_user'] = "Kullanıcı Düzenle";
$l['edit_user_desc'] = "Burada kullanıcıların profilini, ayarlarını ve imzasını düzenleyebilir; genel istatistiklerini görebilir ve bu kullanıcı hakkında daha fazla bilgi edinmek için diğer sayfaları gezebilirsiniz.";
$l['show_referrers'] = "Yönlendirmeleri Göster";
$l['show_referrers_desc'] = "Arama sonuçlarınız aşağıda gösterilmektedir.Sonuçları tablo görünümünde veya kartvizit görünümünde görebilirsiniz.";
$l['show_ip_addresses'] = "IP Bilgilerini Göster";
$l['show_ip_addresses_desc'] = "Kullanıcının kayıt olduğu IP adresi ve mesaj gönderdiği IP adresleri aşağıda gösterilmektedir.İlk IP adresi (İşaretlenen Gibi) kayıt olunan diğerleri de kullanıcının mesaj gönderdiği IP adresleridir.";
$l['manage_users'] = "Kullanıcıları Yönet";
$l['manage_users_desc'] = "Kitle Yönetimi kullanıcıları yönetirken ortak görevleri yerine getirmeyi daha kolay hale getirir.";
$l['inline_edit'] = "Satır İçi Kullanıcı Yönetimi:";
$l['inline_activate'] = "Kullanıcı Aktifleştir";
$l['inline_ban'] = "Kullanıcı Yasakla";
$l['inline_usergroup'] = "Kullanıcı Gruplarını Değiştir";
$l['inline_delete'] = "Kullanıcı Sil";
$l['inline_prune'] = "Kullanıcıların Mesajlarını Sil/Kısalt";
$l['inline_activated'] = "{1} kullanıcı(lar) başarıyla aktifleştirildi.";
$l['inline_activated_more'] = "<small>Seçtiğiniz {1} kullanıcı zaten aktifleştirilmiş.</small>";
$l['inline_activated_failed'] = "Seçtiğiniz bütün kullanıcılar zaten aktifleştirilmiş.";
$l['ban_time'] = "Yasak Süresi <em>*</em>";
$l['ban_reason'] = "Yasak Sebebi";
$l['mass_ban'] = "Kullanıcı Kitlesini Yasakla";
$l['important'] = "Önemli";
$l['mass_ban_info'] = "Bu eylem {1} kullanıcıyı etkileyecek.Eğer devam ederseniz kullanıcıların girdiğiniz tarihten eski mesajları silinecek. <br /><br /><strong>Lütfen kullanıcıların mesajları herhangi bir konunun ilk mesajı ise bütün konunun silineceğini unutmayınız!</strong>";
$l['ban_users'] = "Kullanıcıları Yasakla";
$l['users_banned'] = "{1} kullanıcı yasaklandı.";
$l['confirm_multilift'] = "Seçtiğiniz kullanıcı(lar)ın yasağını kaldırmak istediğinize emin misiniz?";
$l['success_ban_lifted'] = "{1} kullanıcının yasağı kaldırıldı.";
$l['edit_ban'] = "Yasağı Düzenle";
$l['lift_ban'] = "Yasağı Kaldır";
$l['lift_bans'] = "Yasakları Kaldır";
$l['confirm_multidelete'] = "Seçtiğiniz {1} kullanıcıyı silmek istediğinize emin misiniz? Bu eylem geri alınamaz!";
$l['users_deleted'] = "{1} kullanıcı silindi.";
$l['mass_ban_info'] = "Bu eylem {1} kullanıcıyı etkileyecek.Eğer devam ederseniz kullanıcıların girdiğiniz tarihten eski mesajları silinecek. <br /><br /><strong>Lütfen kullanıcıların mesajları herhangi bir konunun ilk mesajı ise bütün konunun silineceğini unutmayınız!</strong>";
$l['mass_prune_posts'] = "Kısaltılmış Mesaj Yığını";
$l['manual_date'] = "Bir tarih girin";
$l['relative_date'] = "Veya silme ayarlarını seçin";
$l['multi_selected_dates'] = "Tarih ile ayar seçiminin ikisini seçemezsiniz.Lütfen sadece birini seçiniz.";
$l['incorrect_date'] = "Girdiğiniz tarih geçersiz.Lütfen geçerli bir tarih girin veya bir ayar seçmek için boş bırakın.";
$l['prune_complete'] = "Kısaltma başarıyla tamamlandı.";
$l['prune_fail'] = "Seçilen kullanıcı(lar)ın hiçbir mesajı bulunamadı. Hiçbir mesaj kısaltılmadı.";
$l['no_prune_option'] = "Lütfen devam etmek için bir tarih girin veya bir ayar seçin.";
$l['prune_posts'] = "Mesajları Kısalt";
$l['delete_posts'] = "Mesajları Sil";
$l['usergroup_info'] = "Yapılacak eylem {1} kullanıcı(lar)ı etkileyecek.Aşağıdaki ayarları seçerek seçilen kullanıcıların birincil, ek, görüntüleme gruplarını değiştirmiş olacaksınız.";
$l['mass_usergroups'] = "Toplu Kullanıcı Grubu Değiştir";
$l['success_mass_usergroups'] = "Kullanıcılar başarıyla güncelleştirildi.";
$l['alter_usergroups'] = "Ayarları Kaydet";
$l['no_usergroup_changed'] = "Seçtiğiniz kullanıcılardan hiçbirinin grubu değiştirilmedi.";
$l['no_set_option'] = "Geçerli bir ayar tarihi seçilmedi.Lütfen açılan kutudan bir ayar seçiniz veya geçerli bir tarih giriniz.";
$l['select_an_option'] = "(Bir Ayar Seçin)";

$l['month_1'] = "Ocak";
$l['month_2'] = "Şubat";
$l['month_3'] = "Mart";
$l['month_4'] = "Nisan";
$l['month_5'] = "Mayıs";
$l['month_6'] = "Haziran";
$l['month_7'] = "Temmuz";
$l['month_8'] = "Ağustos";
$l['month_9'] = "Eylül";
$l['month_10'] = "Ekim";
$l['month_11'] = "Kasım";
$l['month_12'] = "Aralık";

$l['option_1'] = "1 aydan eski";
$l['option_2'] = "3 aydan eski";
$l['option_3'] = "6 aydan eski";
$l['option_4'] = "1 yıldan eski";
$l['option_5'] = "18 aydan eski";
$l['option_6'] = "2 yıldan eski";

$l['error_avatartoobig'] = "Üzgünüz! Ancak seçtiğiniz yeni avatar belirtilenden daha büyük olduğu için avatarınız değiştirilemiyor. Maksimum boyutlar {1}x{2} (genişlik x yükseklik)";
$l['error_invalidavatarurl'] = "Avatarınız için girdiğiniz link geçerli değil. Lütfen, geçerli bir link girdinizden emin olun.";
$l['error_invalid_user'] = "Geçersiz bir kullanıcı seçtiniz.";
$l['error_no_perms_super_admin'] = "Bu kullanıcıyı düzenlemeye yetkiniz yok çünkü Süper Administratör değilsiniz.";
$l['error_invalid_user_source'] = "Girdiğiniz kaynak hesabın kullanıcı ismi mevcut değil.";
$l['error_invalid_user_destination'] = "Girdiğiniz hedef hesabın kullanıcı ismi mevcut değil.";
$l['error_cannot_merge_same_account'] = "Kaynak ve hedef hesaplar birbirinden farklı olmalıdır.";
$l['error_no_users_found'] = "Arama kriterlerine uyan kullanıcı bulunamadı. Lütfen, arama kriterlerini gözden geçirip tekrar deneyiniz.";
$l['error_invalid_admin_view'] = "Geçersiz bir yönetim görünümü seçtiniz.";
$l['error_missing_view_title'] = "Bu görünüm için bir başlık girmediniz.";
$l['error_no_view_fields'] = "Bu görünümde gösterilecek herhangi bir alan seçmediniz.";
$l['error_invalid_view_perpage'] = "Sayfa başında gösterilecek sonuçlar için geçersiz bir sayı girdiniz.";
$l['error_invalid_view_sortby'] = "Sonuçları sıralamak için geçersiz bir alan seçtiniz.";
$l['error_invalid_view_sortorder'] = "Geçersiz bir sıralama seçtiniz.";
$l['error_invalid_view_delete'] = "Silmek için geçersiz bir yönetim görünümü seçtiniz.";
$l['error_cannot_delete_view'] = "En az 1 yönetim görünümü olmalıdır.";
$l['error_inline_no_users_selected'] = "Üzgünüz, ancak hiçbir kullanıcı seçmediniz. Lütfen, kullanıcı seçiniz ve tekrar deneyiniz.";
$l['error_cannot_delete_user'] = "Bu kullanıcı silinemez.";
$l['error_no_referred_users'] = "Seçilen kullanıcı herhangi bir referans sahibi değildir.";

$l['user_deletion_confirmation'] = "Bu kullanıcıyı silmek istediğinizden emin misiniz?";

$l['success_coppa_activated'] = "Seçilen (COPPA) kullanıcı başarıyla aktif edildi.";
$l['success_activated'] = "Seçilen kullanıcı başarıyla aktif edildi.";
$l['success_user_created'] = "Kullanıcı başarıyla oluşturuldu.";
$l['success_user_updated'] = "Seçilen kullanıcı başarıyla güncellendi.";
$l['success_user_deleted'] = "Seçilen kullanıcı başarıyla silindi.";
$l['success_merged'] = "Seçilen kullanıcılar başarıyla birleştirildi.";
$l['succuss_view_set_as_default'] = "Seçilen yönetim görünümü başarıyla varsayılan görünüm yapıldı.";
$l['success_view_created'] = "Yönetim görünümü başarıyla oluşturuldu.";
$l['success_view_updated'] = "Seçilen yönetim görünümü başarıyla güncellendi.";
$l['success_view_deleted'] = "Seçilen yönetim görünümü başarıyla silindi.";

$l['confirm_view_deletion'] = "Seçilen görünümü silmek istediğinizden emin misiniz?";

$l['warning_coppa_user'] = "<p class=\"alert\"><strong>Warning: </strong> Bu kullanıcı COPPA aktifleştirmesi bekliyor. <a href=\"index.php?module=user-users&amp;action=activate_user&amp;uid={1}\">Hesabı Aktifleştir</a></p>";

$l['required_profile_info'] = "Profil Bilgileri";
$l['password'] = "Şifre";
$l['confirm_password'] = "Şifreyi Doğrula";
$l['email_address'] = "E-Posta Adresi";
$l['use_primary_user_group'] = "Birincil Kullanıcı Grubunu Kullan";
$l['primary_user_group'] = "Birincil Kullanıcı Grubu";
$l['additional_user_groups'] = "Ek Kullanıcı Grupları";
$l['additional_user_groups_desc'] = "Çoklu grup seçimi için CTRL'yi kullanınız.";
$l['display_user_group'] = "Gösterilecek Kullanıcı Grubu";
$l['save_user'] = "Kullanıcıyı Kaydet";

$l['overview'] = "Genel Bakış";
$l['profile'] = "Profil";
$l['account_settings'] = "Hesap Ayarları";
$l['signature'] = "İmza";
$l['avatar'] = "Avatar";
$l['mod_options'] = "Moderatör Ayarları";
$l['general_account_stats'] = "Genel Hesap İstatistikleri";
$l['local_time'] = "Şu anki Tarih";
$l['local_time_format'] = "{1}, Saat: {2}";
$l['posts'] = "Toplam Mesajları";
$l['age'] = "Yaşı";
$l['posts_per_day'] = "Günlük Mesaj Ortalaması";
$l['percent_of_total_posts'] = "Toplam Mesajların Yüzdesi";
$l['user_overview'] = "Kullanıcıya Genel Bakış";

$l['new_password'] = "Yeni Şifre";
$l['new_password_desc'] = "Sadece değiştirmek için gerekli";
$l['confirm_new_password'] = "Yeni Şifreyi Onayla";

$l['optional_profile_info'] = "Ek Profil Bilgisi";
$l['custom_user_title'] = "Özel Kullanıcı Başlığı";
$l['custom_user_title_desc'] = "Eğer boş bırakırsanız kullanıcı grubunun başlığı kullanılacaktır.";
$l['website'] = "Web Site Adresi";
$l['icq_number'] = "ICQ Numarası";
$l['aim_handle'] = "AIM Ekran Adı";
$l['yahoo_messanger_handle'] = "Yahoo ID";
$l['skype_handle'] = "Skype ID";
$l['google_handle'] = "Google Talk ID";
$l['birthday'] = "Doğum Tarihi";

$l['away_information'] = "İzin Bilgileri";
$l['away_status'] = "İzin Durumu:";
$l['away_status_desc'] = "Eğer uzun bir süre aktif olunmayacaksa, bu alan kullanıcılara profilde gösterilmesi için bilgi amaçlı kullanabilir.";
$l['im_away'] = "İzindeyim";
$l['im_here'] = "Geldim";
$l['away_reason'] = "İzinli Olma Sebebi:";
$l['away_reason_desc'] = "Neden izinli olunduğuna dair kısa bir açıklama giriniz. (maks. 200 karakter kullanılabilir)";
$l['return_date'] = "İzinden Dönüş Tarihi:";
$l['return_date_desc'] = "Eğer dönüş tarihini belirtmek istiyorsanız bu kısımdan seçiniz.";
$l['error_acp_return_date_past'] = "Geçmiş bir tarih, dönüş tarihi olarak belirtilemez! Lütfen, geri dönüp doğru bir tarih giriniz.";

$l['hide_from_whos_online'] = "Kimler Çevrimiçi listesinde gizle?";
$l['login_cookies_privacy'] = "Gizlilik Ayarı";
$l['recieve_admin_emails'] = "Yönetimden bilgi E-Postaları gönderilsin?";
$l['hide_email_from_others'] = "Profilindeki ''E-Posta Gönder'' bağlantısını Gizle?";
$l['recieve_pms_from_others'] = "Tüm kullanıcılar Özel Mesaj gönderebilsin?";
$l['recieve_pms_from_buddy'] = "Sadece, arkadaş listesinde ekli kullanıcılar Özel Mesaj gönderebilsin?";
$l['alert_new_pms'] = "Yeni Özel Mesaj aldığında bildirim gösterilsin?";
$l['email_notify_new_pms'] = "Yeni Özel Mesaj aldığında E-Posta bildirimi gönderilsin?";
$l['buddy_requests_pm'] = "Yeni arkadaşlık isteklerinde Özel Mesaj gönderilsin?";
$l['buddy_requests_auto'] = "Eğer yukarıdaki seçenek seçili ise, otomatik olarak Arkadaşlık istekleri kabulü için; bağlantılı bir Özel Mesaj gönderilir.";
$l['default_thread_subscription_mode'] = "<strong>Konu Abonelik/Takip Seçenekleri</strong>";
$l['do_not_subscribe'] = "Abonelik İptal Edilsin?";
$l['no_email_notification'] = "E-Posta Bildirimi Gönderilmesin?";
$l['instant_email_notification'] = "Anında E-Posta Bildirimi Gönderilsin?";
$l['messaging_and_notification'] = "Mesaj & Bildirim Ayarları";
$l['use_default'] = "Varsayılanı Kullan";
$l['date_format'] = "Tarih Formatı";
$l['time_format'] = "Saat Formatı";
$l['time_zone'] = "Zaman Dilimi Ayarları";
$l['daylight_savings_time_correction'] = "Yaz / Kış Sezonu Saati (<acronym title=\"Daylight Saving Time\">DST</acronym>) Zaman Ayarları";
$l['automatically_detect'] = "Yaz / Kış Sezonu Saatini Otomatik Olarak Tanı";
$l['always_use_dst_correction'] = "Her Zaman Yaz / Kış Sezonu Saatini Kullan";
$l['never_use_dst_correction'] = "Yaz / Kış Sezonu Saatini Devre Dışı Bırak";
$l['date_and_time_options'] = "Tarih & Saat Ayarları";
$l['show_threads_last_day'] = "Bugünkü Konuları Göster";
$l['show_threads_last_5_days'] = "Son 5 Günlük Konuları Göster";
$l['show_threads_last_10_days'] = "Son 10 Günlük Konuları Göster";
$l['show_threads_last_20_days'] = "Son 20 Günlük Konuları Göster";
$l['show_threads_last_50_days'] = "Son 50 Günlük Konuları Göster";
$l['show_threads_last_75_days'] = "Son 75 Günlük Konuları Göster";
$l['show_threads_last_100_days'] = "Son 100 Günlük Konuları Göster";
$l['show_threads_last_year'] = "1 Yıllık Konuları Göster";
$l['show_all_threads'] = "Tüm Konuları Göster";
$l['threads_per_page'] = "Sayfa Başına Konu Gösterimi";
$l['default_thread_age_view'] = "Varsayılan Konu Gösterimi";
$l['forum_display_options'] = "Forum Görüntüleme Ayarları";
$l['show_classic_postbit'] = "Konu ve yorumları klasik mod, (Dikey Postbit) olarak göster?";
$l['display_images'] = "Konu ve yorumlarda eklenen resimleri göster?";
$l['display_videos'] = "Konu ve yorumlarda eklenen videoları göster?";
$l['display_users_sigs'] = "Konu ve yorumlarda Kullanıcıların imzalarını göster?";
$l['display_users_avatars'] = "Konu ve yorumlarda Kullanıcıların avatarlarını göster";
$l['show_quick_reply'] = "Konu görüntülemede ''hızlı cevap'' editörünü göster?";
$l['posts_per_page'] = "Sayfa Başına Yorum Gösterimi";
$l['default_thread_view_mode'] = "Konu Gösterim Modu";
$l['linear_mode'] = "Tam Görünüm";
$l['threaded_mode'] = "Konu Görünümü";
$l['thread_view_options'] = "Konu Gösterimi Ayarları";
$l['show_redirect'] = "Yönlendirme sayfalarını göster?";
$l['source_editor'] = "Mesaj editörünü varsayılan kaynak modunda kullanılsın?";
$l['show_code_buttons'] = "Mesaj editöründe Mykod, (BBcode) butonlarını göster?";
$l['theme'] = "Forum Teması";
$l['board_language'] = "Forum Dili";
$l['other_options'] = "Diğer Ayarlar";
$l['signature_desc'] = "İzinler: İfade Kullanımı <strong>{2}</strong>, [MyKod] Kullanımı <strong>{1}</strong>, [İMG] Etiketi Kullanımı <strong>{3}</strong>, [HTML] Kod Kullanımı <strong>{4}</strong>";
$l['enable_sig_in_all_posts'] = "Tüm konu ve yorumlarda imzayı göster";
$l['disable_sig_in_all_posts'] = "Tüm konu ve yorumlarda imzayı gösterime kapat";
$l['do_nothing'] = "Hiçbir şey yapma";
$l['signature_preferences'] = "İmza Tercihleri";
$l['suspend_sig'] = "İmzayı askıya al";
$l['suspend_sig_box'] = "Bu kullanıcının imzasını askıya al";
$l['suspend_sig_perm'] = "<small>Kalıcı olarak askıya alındı</small>";
$l['suspend_sig_info'] = "Eğer bir imza askıya alınmışsa, kullanıcı onu düzenleyemez ve kullanıcının profilinde veya mesajlarında gösterilmez.";
$l['suspend_sig_extend'] = "<small>Aşağıya yeni bir zaman girin ya da askıyı kaldırmak için bu seçeneğin işaretini kaldırın.</small>";
$l['suspend_expire_info'] = "<small>Sona Eren: <span style=\"color: {2};\">{1}</span></small>";
$l['suspend_never_expire'] = "<small>{1} kullanıcının askısı asla sona ermeyecek.(Kalıcı olarak askıya alındı.)</small>";
$l['suspend_sig_error'] = "Kullanıcının imzasını askıya almak için geçersiz bir zaman girdiniz.Lütfen geçerli bir zaman giriniz.";

$l['moderate_posts'] = "Konu & Yorumlarını Yönet";
$l['moderate_posts_info'] = "<strong>{1}</strong>, tarafından gönderilen tüm yeni konu & yorumlar moderasyon işlemi gerektirsin?";
$l['moderate_for'] = "Rakam Giriniz:";
$l['moderated_perm'] = "<p><small>Süresiz olarak moderasyona alındı.<br />Bu moderasyon işlemini iptal etmek için üsteki kutucuğun tik işaretini kaldırın.</small></p>";
$l['moderate_length'] = "<p><small><span style=\"color: {2};\">{1}</span>, Moderasyona alındı.<br />Bu moderasyon işlemini iptal etmek için üsteki kutucuğun tik işaretini kaldırın. Yeni bir süre girmek için aşağıdaki kısımdan yeni bir zaman dilimini seçiniz.</small></p>";

$l['suspend_posts'] = "Konu & Yorumlarını Askıya Al";
$l['suspend_posts_info'] = "<strong>{1}</strong>, tarafından gönderilen tüm yeni konu & yorumlar askıya alınsın?";
$l['suspend_for'] = "Rakam Giriniz:";
$l['suspended_perm'] = "<p><small>Süresiz olarak askıya alındı.<br />Bu askıyı iptal etmek için üsteki kutucuğun tik işaretini kaldırın.</small></p>";
$l['suspend_length'] = "<p><small><span style=\"color: {2};\">{1}</span>, askıya alındı.<br />Bu askıyı iptal etmek için üsteki kutucuğun tik işaretini kaldırın. Yeni bir süre girmek için aşağıdaki kısımdan yeni bir zaman dilimini seçiniz.</small></p>";

$l['suspendsignature_error'] = "Bu kullanıcının imzasını askıya almayı seçtiniz ancak devam etmek için geçerli bir zaman girmediniz.Lütfen geçerli bir zaman girin veya iptal etmek için bu seçeneğin işaretini kaldırın.";
$l['moderateposting_error'] = "Bu kullanıcının mesajlarını düzenlemeyi seçtiniz ancak geçerli bir zaman periyodu girmediniz.Devam etmek için lütfen geçerli bir zaman periyodu girin veya iptal etmek için bu seçeneğin işaretini kaldırınç";
$l['suspendposting_error'] = "Bu kullanıcının mesajlarını askıya almayı seçtiniz ancak geçerli bir zaman periyodu girmediniz.Devam etmek için lütfen geçerli bir zaman periyodu girin veya iptal etmek için bu seçeneğin işaretini kaldırın.";
$l['suspendmoderate_error'] = "Kullanıcının mesajlarını askıya almayı ve düzenlemeyi seçtiniz.Lütfen sadece bir yönetim şekli seçiniz.";

$l['expire_length'] = "Askıya alma süresi:";
$l['expire_hours'] = "Saat";
$l['expire_days'] = "Gün";
$l['expire_weeks'] = "Hafta";
$l['expire_months'] = "Ay";
$l['expire_never'] = "Asla";
$l['expire_permanent'] = "Süresiz";

$l['username'] = "Kullanıcı Adı";
$l['email'] = "E-Posta Adresi";
$l['primary_group'] = "Birincil Grup";
$l['additional_groups'] = "Ek Gruplar";
$l['registered'] = "Üyelik Tarihi";
$l['last_active'] = "Son Ziyareti";
$l['post_count'] = "Yorum Sayısı";
$l['thread_count'] = "Konu Sayısı";
$l['reputation'] = "Rep Puanı";
$l['warning_level'] = "Uyarı Seviyesi";
$l['registration_ip'] = "Kayıt Olunan IP Adresi";
$l['last_known_ip'] = "Son Bilinen IP Adresi Uyuşması";
$l['registration_date'] = "Üyelik Tarihi";
$l['info_on_ip'] = "Bu IP Adresine Ait Bilgileri Göster";

$l['current_avatar'] = "Mevcut Avatar";
$l['user_current_using_uploaded_avatar'] = "Bu kullanıcı yüklenmiş bir avatar kullanıyor.";
$l['user_currently_using_remote_avatar'] = "Bu kullanıcı uzaktan linklendirilmiş bir avatar kullanıyor.";
$l['max_dimensions_are'] = "Avatar için izin verilen maksimum resim buyutları:";
$l['avatar_max_size'] = "Avatar için izin verilen maksimum dosya boyutu:";
$l['remove_avatar'] = "Mevcut Avatarı Sil?";
$l['avatar_desc'] = "Bu kısımdan, kullanıcının avatarını yönetebilirsiniz.";
$l['avatar_auto_resize'] = "Eğer avatar çok büyükse otomatik olarak boyutlandırılır.";
$l['attempt_to_auto_resize'] = "Avatar çok büyükse yeniden boyutlandırılsın mı?";
$l['specify_custom_avatar'] = "Özel Avatar Yükle";
$l['upload_avatar'] = "Avatar Resmi Yükle:";
$l['or_specify_avatar_url'] = "Veya avatar için resim URL'si giriniz:";

$l['user_notes'] = "Kullanıcı Notları";

$l['ip_addresses'] = "IP Bilgileri";
$l['ip_address'] = "IP Adresleri";
$l['show_users_regged_with_ip'] = "Bu IP adresinden kayıt olan kullanıcıları göster";
$l['show_users_posted_with_ip'] = "Bu IP adresinden konu/yorum gönderen kullanıcıları göster";
$l['ban_ip'] = "Bu IP Adresini Yasakla";
$l['ip_address_for'] = "IP Bilgileri Görüntülenen Kullanıcı:";

$l['source_account'] = "Kaynak Hesap";
$l['source_account_desc'] = "Bu hesap hedef hesapta birleştirilecek olan hesaptır.Bu işlemden sonra silinecektir.";
$l['destination_account'] = "Hedef Hesap";
$l['destination_account_desc'] = "Bu hesap kaynak hesabın birleştirileceği hesaptır.Bu işlemden sonra kalacaktır.";
$l['merge_user_accounts'] = "Kullanıcı Hesaplarını Birleştir";

$l['display_options'] = "Ayarları Göster";
$l['ascending'] = "Artan";
$l['descending'] = "Azalan";
$l['sort_results_by'] = "Listeleme Metodu Seç:";
$l['in'] = "-";
$l['results_per_page'] = "Sayfa Başına Gösterilecek Sonuç:";
$l['display_results_as'] = "Gösterim Modu Seç:";
$l['business_card'] = "Kartvizit Modu";
$l['views'] = "Görünüm Ayarları";
$l['views_desc'] = "Görünüm yöneticisi belirtilen alan için farklı şekillerde görünümler oluşturmanıza olanak sağlar. Farklı görünümler çeşitli raporlar oluşturmak için kullanışlıdır.";
$l['manage_views'] = "Görünümleri Yönet";
$l['none'] = "Hiçbiri";
$l['search'] = "Ara";

$l['view_profile'] = "Profilini Görüntüle";
$l['edit_profile_and_settings'] = "Profilini Düzenle";
$l['ban_user'] = "Kullanıcıyı Yasakla";
$l['approve_coppa_user'] = "COPPA Kullanıcıyı Aktifleştir";
$l['approve_user'] = "Kullanıcıyı Aktifleştir";
$l['delete_user'] = "Kullanıcıyı Sil";
$l['show_referred_users'] = "Referanslarını Göster";
$l['show_attachments'] = "Ek Dosyalarını Göster";
$l['table_view'] = "Tablo Modu";
$l['card_view'] = "Kartvizit Modu";

$l['find_users_where'] = "Kullanıcı Ara/Bul";
$l['username_contains'] = "Şu Kullanıcı Adı:";
$l['email_address_contains'] = "Şu E-Posta Adresi:";
$l['is_member_of_groups'] = "Şu Kullanıcı Grupları:";
$l['website_contains'] = "Web Site adresi şunları içerir:";
$l['icq_number_contains'] = "ICQ numarası şunları içerir:";
$l['aim_handle_contains'] = "AIM ekran adı şunları içerir:";
$l['yahoo_contains'] = "Yahoo ID şunları içerir:";
$l['skype_contains'] = "Skype ID şunları içerir:";
$l['google_contains'] = "Google Talk ID şunları içerir:";
$l['signature_contains'] = "İmza şunları içerir:";
$l['user_title_contains'] = "Özel kullanıcı başlığı şunları içerir:";
$l['greater_than'] = "Daha Fazla";
$l['is_exactly'] = "Tam Olarak";
$l['less_than'] = "Daha Az";
$l['post_count_is'] = "Şu Yorum Sayısı Aralığında ki Kullanıcılar:";
$l['thread_count_is'] = "Şu Konu Sayısı Aralığında ki Kullanıcılar:";
$l['reg_ip_matches'] = "Kayıt olunan IP Adresi ile bul:";
$l['wildcard'] = "Bir IP Adres dizisini aramak için * işaretini kullanınız. (Örnek: 127.0.0.*) veya (Örnek: 127.0.0.0/8)";
$l['posted_with_ip'] = "Konu/Yorum gönderdiği IP Adresi ile bul:";
$l['custom_profile_fields_match'] = "Özel profil alanları şunları içerir:";
$l['is_not_blank'] = " Zorunlu arama olarak işaretle <img src=\"../images/valid.gif\" style=\"vertical-align: middle;\" alt=\"\" border=\"0\">";
$l['or'] = "<img src=\"../images/admincp/vurgu.gif\" style=\"vertical-align: middle;\" alt=\"\" border=\"0\">";
$l['reg_in_x_days'] = "Şu Zaman Aralığında kayıt olan:";
$l['days'] = "";

$l['view'] = "Görünüm Adı";
$l['create_new_view'] = "Yeni Görünüm Oluştur";
$l['create_new_view_desc'] = "Bu kısımdan, yeni bir özel ya da genel görünüm oluşturabilirsiniz.";
$l['view_manager'] = "Görünüm Yöneticisi";
$l['set_as_default_view'] = "Varsayılan Görünüm Olarak Ayarla?";
$l['enabled'] = "Aktif Alanlar";
$l['disabled'] = "Pasif Alanlar";
$l['fields_to_show'] = "Gösterilecek Alanları Seç";
$l['fields_to_show_desc'] = "Göstermek istediğiniz alanları pasif alan bölümünden sürükleyip aktif alan bölümüne bırakınız. (ya da tam tersi)";
$l['edit_view'] = "Görünümü Düzenle";
$l['edit_view_desc'] = "Bir görünümü düzenlerken herhangi bir arama kriteri ve sıralama seçeneklerini, gösterilmesini istediğiniz alanları tanımlayabilirsiniz.";
$l['private'] = "Özel";
$l['private_desc'] = "Bu görünüm sadece size görünür.";
$l['public'] = "Genel";
$l['public_desc'] = "Bu görünüm diğer tüm adminlere görünür.";
$l['visibility'] = "Kimlere Görünür?";
$l['save_view'] = "Görünümü Kaydet";
$l['created_by'] = "Tarafından oluşturuldu:";
$l['default'] = "Varsayılan";
$l['this_is_a_view'] = "Bu {1} Görünümüdür.";
$l['set_as_default'] = "Varsayılan Yap";
$l['delete_view'] = "Görünümü Sil";
$l['default_view_desc'] = "Varsayılan görünüm MyBB kodlayıcıları tarafından oluşturulmuştur. Düzenlenebilir fakat, silinemez.";
$l['public_view_desc'] = "Genel görünüm tüm adminlere görünür. Düzenlenebilir veya silinebilir.";
$l['private_view_desc'] = "Özel görünüm sadece size görünür. Düzenlenebilir veya silinebilir.";
$l['table'] = "Tablo Modu";
$l['title'] = "Başlık";

$l['view_title_1'] = "Tüm Kullanıcılar";

$l['emailsubject_activateaccount'] = "{1} Hesap Aktif Edildi";
$l['email_adminactivateaccount'] = "{1},

{2}, Yönetim tarafından hesabınız aktif edilmiştir.

Devam etmek için aşağıdaki adresi ziyaret ediniz.

{3}

Kayıt sırasında kullandığınız kullanıcı adı/E-Posta ve şifre ile giriş yapabilirsiniz.

Teşekkürler,
{2} - Yönetimi";

$l['ipaddress_misc_info'] = "IP Adresi: '{1}'";
$l['ipaddress_host_name'] = "Host Adı";
$l['ipaddress_location'] = "IP Lokasyonu";

