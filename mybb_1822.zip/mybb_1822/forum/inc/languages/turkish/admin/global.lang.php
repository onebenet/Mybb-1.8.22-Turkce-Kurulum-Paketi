﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 * Copyright © 2014 TR - MyBBG
 */

$l['today'] = "Bugün";
$l['yesterday'] = "Dün";

$l['size_yb'] = "YB";
$l['size_zb'] = "ZB";
$l['size_eb'] = "EB";
$l['size_pb'] = "PB";
$l['size_tb'] = "TB";
$l['size_gb'] = "GB";
$l['size_mb'] = "MB";
$l['size_kb'] = "KB";
$l['size_bytes'] = "Bayt";
$l['na'] = "N/A";

// Header language strings
$l['mybb_admin_panel'] = "MyBB Admin Kontrol Paneli";
$l['mybb_admin_cp'] = "MyBB Admin Paneli";
$l['logged_in_as'] = "Merhaba,";
$l['view_board'] = "Forumu Görüntüle";
$l['logout'] = "Çıkış Yap";

// Footer language strings
$l['generated_in'] = "Sayfa: {1} Oluşturuldu. <a rel=\"nofollow\" href=\"{2}\" target=\"_blank\">{3} Sorgular</a>. Bellek Kullanımı: {4}";

// Login page
$l['enter_username_and_password'] = "Lütfen, giriş yapmak için gerekli alanları doldurunuz.";
$l['login_username'] = 'Kullanıcı Adı';
$l['login_email'] = 'E-Posta';
$l['login_username_and_password'] = 'Kullanıcı Adı/E-Posta';
$l['mybb_admin_login'] = "Admin KP - Giriş";
$l['return_to_forum'] = "Foruma Git";
$l['please_login'] = "Lütfen Giriş Yapınız";
$l['username'] = "Kullanıcı Adı:";
$l['username1'] = "E-Posta Adresi:";
$l['username2'] = "Kullanıcı Adı/E-Posta:";
$l['password'] = "Şifre:";
$l['secret_pin'] = "Güvenlik Kodu:";
$l['login'] = "Giriş Yap";
$l['lost_password'] = "Şifremi Unuttum?";

$l['error_invalid_admin_session'] = "Geçersiz Yönetici Girişi";
$l['error_admin_session_expired'] = "Yönetici oturumunuzun süresi doldu.";
$l['error_invalid_ip'] = "IP adresiniz giriş için geçerli değil.";
$l['error_mybb_admin_lockedout'] = "Bu yönetici hesabı kilitlenmiştir.";
$l['error_mybb_admin_lockedout_message'] = "Yönetici hesabınızla, {1} defa başarısız giriş yaptığınız için kilitlenmiştir.<br />Hesabınızı tekrar açmak/aktif etmek için gerekli bilgiler e-posta adresinize gönderildi.";
$l['error_invalid_secret_pin'] = 'Girilen ek şifre/güvenlik kodu (Secret PIN) geçersiz.';

$l['error_invalid_username'] = "Girilen kullanıcı adı geçersiz.";
$l['error_invalid_uid'] = "Girilen kullanıcı kimliği (İD'si) geçersiz.";
$l['error_invalid_token'] = "Girilen etkinleştirme kodu geçersiz.";

$l['success_logged_out'] = "Başarılı olarak çıkış yaptınız.";
$l['error_invalid_username_password'] = "Girilen bilgiler, giriş yapabilmeniz için geçerli değil.";

// Action Confirmation
$l['confirm_action'] = "Bu işlemi gerçekleştirmek istediğinizden emin misiniz?";

// Common words and phrases
$l['home'] = "Başlangıç";
$l['name'] = "İsim";
$l['size'] = "Boyut";
$l['controls'] = "Kontroller";
$l['view'] = "Gösterim";
$l['yes'] = "Evet";
$l['no'] = "Hayır";
$l['cancel'] = "İptal";
$l['options'] = "Seçenekler";
$l['proceed'] = "Devam Et";
$l['ok'] = "Tamam";
$l['error'] = "Hata";
$l['edit'] = "Düzenle";
$l['never'] = "Hiçbir Zaman";
$l['legend'] = "Bilgi";
$l['version'] = "Versiyon";
$l['languagevar'] = "Dil";
$l['use_default'] = "Varsayılan";
$l['file'] = "Dosya";
$l['go'] = "Git";
$l['clear'] = "Temizle";
$l['unknown'] = "Bilinmeyen";
$l['year'] = "Yıl";
$l['year_short'] = "y";
$l['years'] = "Yıl";
$l['years_short'] = "y";
$l['month'] = "Ay";
$l['month_short'] = "a";
$l['months'] = "Ay";
$l['months_short'] = "a";
$l['week'] = "Hafta";
$l['week_short'] = "h";
$l['weeks'] = "Hafta";
$l['weeks_short'] = "h";
$l['day'] = "Gün";
$l['day_short'] = "g";
$l['days'] = "Gün";
$l['days_short'] = "g";
$l['hour'] = "Saat";
$l['hour_short'] = "s";
$l['hours'] = "Saat";
$l['hours_short'] = "s";
$l['minute'] = "Dakika";
$l['minute_short'] = "d";
$l['minutes'] = "Dakika";
$l['minutes_short'] = "dk";
$l['second'] = "Saniye";
$l['second_short'] = "sn";
$l['seconds'] = "Saniye";
$l['seconds_short'] = "sn";
$l['permanent'] = "Süresiz";
$l['all_forums'] = "Tüm Forumlar";
$l['all_groups'] = "Tüm Gruplar";
$l['select_forums'] = "Forum Seç";
$l['select_groups'] = "Grup Seç";
$l['forums_colon'] = "Forumlar:";
$l['groups_colon'] = "Gruplar:";
$l['none'] = "Hiçbiri";
$l['mybb_acp'] = "Admin Kontrol Paneli";
$l['pages'] = "Sayfalar";
$l['previous'] = "Önceki";
$l['page'] = "Sayfa";
$l['next'] = "Sonraki";
$l['delete'] = "Sil";
$l['reset'] = "Sıfırla";
$l['and'] = "ve";
$l['on'] = "Açık";
$l['off'] = "Kapalı";
$l['alt_enabled'] = "Aktif";
$l['alt_disabled'] = "Pasif";
$l['enable'] = "Aktif Et";
$l['disable'] = "Devre Dışı Bırak";
$l['saved'] = 'Kayıtlı';

$l['rel_in'] = "";
$l['rel_ago'] = "önce";
$l['rel_less_than'] = "";
$l['rel_time'] = "{1}{2} {3} {4}";
$l['rel_minutes_single'] = "dakika";
$l['rel_minutes_plural'] = "dakika";
$l['rel_hours_single'] = "saat";
$l['rel_hours_plural'] = "saat";

// Parser bits
$l['quote'] = "Alıntı:";
$l['wrote'] = "Yazar:";
$l['code'] = "Kod:";
$l['php_code'] = "PHP Kod:";
$l['linkback'] = "Orjinal Konu";

// The months of the year
$l['january'] = "Ocak";
$l['february'] = "Şubat";
$l['march'] = "Mart";
$l['april'] = "Nisan";
$l['may'] = "Mayıs";
$l['june'] = "Haziran";
$l['july'] = "Temmuz";
$l['august'] = "Ağustos";
$l['september'] = "Eylül";
$l['october'] = "Ekim";
$l['november'] = "Kasım";
$l['december'] = "Aralık";

// Access Denied
$l['access_denied'] = "Erişim Engellendi";
$l['access_denied_desc'] = "Admin kontrol panelinin, bu bölümüne erişim izniniz bulunmamaktadır.";

// Super Administrator required
$l['cannot_perform_action_super_admin_general'] = "Üzgünüz, işleminiz gerçekleştirilemedi. Çünkü, Süper Admin değilsiniz.<br /><br />Bu işlemi gerçekleştirebilmek için <strong>./inc/config.php</strong> dosyasındaki <strong>\$config['super_admins']</strong> satırında, kullanıcı <strong>ID</strong> numaranızın ekli olması gerekiyor.";

// AJAX
$l['loading_text'] = "Sayfa Yükleniyor<br />Lütfen Bekleyiniz...";

// Time zone selection boxes
$l['timezone_gmt_minus_1200'] = "(GMT -12:00) Howland and Baker Islands";
$l['timezone_gmt_minus_1100'] = "(GMT -11:00) Nome, Midway Island";
$l['timezone_gmt_minus_1000'] = "(GMT -10:00) Hawaii, Papeete";
$l['timezone_gmt_minus_950'] = "(GMT -9:30) Marquesas Islands";
$l['timezone_gmt_minus_900'] = "(GMT -9:00) Alaska";
$l['timezone_gmt_minus_800'] = "(GMT -8:00) Pacific Time";
$l['timezone_gmt_minus_700'] = "(GMT -7:00) Mountain Time";
$l['timezone_gmt_minus_600'] = "(GMT -6:00) Central Time, Mexico City";
$l['timezone_gmt_minus_500'] = "(GMT -5:00) Eastern Time, Bogota, Lima, Quito";
$l['timezone_gmt_minus_450'] = "(GMT -4:30) Caracas";
$l['timezone_gmt_minus_400'] = "(GMT -4:00) Atlantic Time, La Paz, Halifax";
$l['timezone_gmt_minus_350'] = "(GMT -3:30) Newfoundland";
$l['timezone_gmt_minus_300'] = "(GMT -3:00) Brazil, Buenos Aires, Georgetown, Falkland Is.";
$l['timezone_gmt_minus_200'] = "(GMT -2:00) Mid-Atlantic, South Georgia and the South Sandwich Islands";
$l['timezone_gmt_minus_100'] = "(GMT -1:00) Azores, Cape Verde Islands";
$l['timezone_gmt'] = "(GMT) Casablanca, Dublin, Edinburgh, London, Lisbon, Monrovia";
$l['timezone_gmt_100'] = "(GMT +1:00) Berlin, Brussels, Copenhagen, Madrid, Paris, Rome, Warsaw";
$l['timezone_gmt_200'] = "(GMT +2:00) Athens, İstanbul, Cairo, Jerusalem, South Africa";
$l['timezone_gmt_300'] = "(GMT +3:00) Kaliningrad, Minsk, Baghdad, Riyadh, Nairobi";
$l['timezone_gmt_350'] = "(GMT +3:30) Tehran";
$l['timezone_gmt_400'] = "(GMT +4:00) Moscow, Abu Dhabi, Baku, Muscat, Tbilisi";
$l['timezone_gmt_450'] = "(GMT +4:30) Kabul";
$l['timezone_gmt_500'] = "(GMT +5:00) Islamabad, Karachi, Tashkent";
$l['timezone_gmt_550'] = "(GMT +5:30) Mumbai, Calcutta, Madras, New Delhi";
$l['timezone_gmt_575'] = "(GMT +5:45) Kathmandu";
$l['timezone_gmt_600'] = "(GMT +6:00) Almaty, Dhakra, Yekaterinburg";
$l['timezone_gmt_650'] = "(GMT +6:30) Yangon";
$l['timezone_gmt_700'] = "(GMT +7:00) Bangkok, Hanoi, Jakarta";
$l['timezone_gmt_800'] = "(GMT +8:00) Beijing, Hong Kong, Perth, Singapore, Taipei, Manila";
$l['timezone_gmt_850'] = "(GMT +8:30) Pyongyang";
$l['timezone_gmt_875'] = "(GMT +8:45) Eucla";
$l['timezone_gmt_900'] = "(GMT +9:00) Osaka, Sapporo, Seoul, Tokyo, Irkutsk";
$l['timezone_gmt_950'] = "(GMT +9:30) Adelaide, Darwin";
$l['timezone_gmt_1000'] = "(GMT +10:00) Melbourne, Papua New Guinea, Sydney, Yakutsk";
$l['timezone_gmt_1050'] = "(GMT +10:30) Lord Howe Island";
$l['timezone_gmt_1100'] = "(GMT +11:00) Magadan, New Caledonia, Solomon Islands, Vladivostok";
$l['timezone_gmt_1150'] = "(GMT +11:30) Norfolk Island";
$l['timezone_gmt_1200'] = "(GMT +12:00) Auckland, Wellington, Fiji, Marshall Islands";
$l['timezone_gmt_1275'] = "(GMT +12:45) Chatham Islands";
$l['timezone_gmt_1300'] = "(GMT +13:00) Samoa, Tonga, Tokelau";
$l['timezone_gmt_1400'] = "(GMT +14:00) Line Islands";
$l['timezone_gmt_short'] = "GMT {1}({2})";

// Global language strings used for log deletion pages
$l['confirm_delete_logs'] = "Seçilen Günlük Girişler Ayıklansın Mı?";
$l['confirm_delete_all_logs'] = "Tüm Günlük Girişler Ayıklansın Mı?";
$l['selected_logs_deleted'] = "Seçmiş Olduğunuz Günlük Girişler Silindi.";
$l['all_logs_deleted'] = "Tüm Günlük Girişleri Silindi.";
$l['delete_selected'] = "Seçilmiş Olanları Sil";
$l['delete_all'] = "Tüm Filtreleri Sil";

// Misc
$l['encountered_errors'] = "Aşağıdaki hatalar tespit edildi.";
$l['invalid_post_verify_key'] = "Bir yetkilendirme kodu uyumsuzluğu oluştu. Lütfen, gerçekleştirmek istediğiniz eylemi doğrulayın.";
$l['invalid_post_verify_key2'] = "Bir yetkilendirme kodu uyumsuzluğu oluştu. Lütfen, doğru bir sayfaya eriştiğinizi kontrol ediniz.";
$l['unknown_error'] = "Bilinmeyen bir hata oluştu.";

// Code buttons editor language strings
$l['editor_bold'] = "Kalın yazı";
$l['editor_italic'] = "Eğik yazı";
$l['editor_underline'] = "Altı çizik yazı";
$l['editor_strikethrough'] = "Üstü çizik yazı";
$l['editor_subscript'] = "Alt simge";
$l['editor_superscript'] = "Üst simge";
$l['editor_alignleft'] = "Yazıyı sola yasla";
$l['editor_center'] = "Yazıyı ortala";
$l['editor_alignright'] = "Yazıyı sağa yasla";
$l['editor_justify'] = "Yazıyı her iki tarafa hizala";
$l['editor_fontname'] = "Yazı tipi";
$l['editor_fontsize'] = "Yazı boyutu";
$l['editor_fontcolor'] = "Yazı rengi";
$l['editor_removeformatting'] = "Metin biçimini sil";
$l['editor_cut'] = "Kes";
$l['editor_copy'] = "Kopyala";
$l['editor_paste'] = "Yapıştır";
$l['editor_cutnosupport'] = "Tarayıcınız kesme komutuna izin vermiyor. Lütfen, Ctrl/Cmd-X klavye kısayolunu kullanın.";
$l['editor_copynosupport'] = "Tarayıcınız kopyalama komutuna izin vermiyor. Lütfen, Ctrl/Cmd-C klavye kısayolunu kullanın.";
$l['editor_pastenosupport'] = "Tarayıcınız yapıştırma komutuna izin vermiyor. Lütfen, Ctrl/Cmd-V klavye kısayolunu kullanın.";
$l['editor_pasteentertext'] = "Aşağıdaki kutu içine metni yapıştırın:";
$l['editor_pastetext'] = "Metni Yapıştır";
$l['editor_numlist'] = "Numaralı liste";
$l['editor_bullist'] = "Noktalı liste";
$l['editor_undo'] = "1 adım Geri git";
$l['editor_redo'] = "1 adım ileri git";
$l['editor_rows'] = "Satır:";
$l['editor_cols'] = "Sütun:";
$l['editor_inserttable'] = "Tablo ekle";
$l['editor_inserthr'] = "Yatay ayraç çizgisi ekle";
$l['editor_code'] = "Kod ekle (Code)";
$l['editor_php'] = "PHP kod ekle (PHP Code)";
$l['editor_width'] = "Genişlik (opsiyonel):";
$l['editor_height'] = "Yükseklik (opsiyonel):";
$l['editor_insertimg'] = "Resim ekle";
$l['editor_email'] = "E-Posta Adresi:";
$l['editor_insertemail'] = "E-Posta adresi ekle";
$l['editor_url'] = "URL Adresi:";
$l['editor_insertlink'] = "Link ekle";
$l['editor_unlink'] = "Linki sil";
$l['editor_more'] = "Daha fazla göster";
$l['editor_insertemoticon'] = "İfade ekle";
$l['editor_videourl'] = "Video URL:";
$l['editor_videotype'] = "Video Türü:";
$l['editor_insert'] = "Ekle";
$l['editor_insertyoutubevideo'] = "YouTube videosu ekle";
$l['editor_currentdate'] = "Şu anki tarihi ekle";
$l['editor_currenttime'] = "Şu anki saati ekle";
$l['editor_print'] = "Yazdır";
$l['editor_viewsource'] = "Kaynağı görüntüle";
$l['editor_description'] = "Açıklama (opsiyonel):";
$l['editor_enterimgurl'] = "Resim URL'si girin:";
$l['editor_enteremail'] = "E-Posta adresi girin:";
$l['editor_enterdisplayedtext'] = "Görüntülenecek metni girin:";
$l['editor_enterurl'] = "URL adresi girin:";
$l['editor_enteryoutubeurl'] = "YouTube video URL'si yada ID'si girin:";
$l['editor_insertquote'] = "Alıntı yazı ekle (Quote)";
$l['editor_invalidyoutube'] = "Geçersiz YouTube videosu";
$l['editor_dailymotion'] = "Dailymotion";
$l['editor_metacafe'] = "MetaCafe";
$l['editor_veoh'] = "Veoh";
$l['editor_vimeo'] = "Vimeo";
$l['editor_youtube'] = "Youtube";
$l['editor_facebook'] = "Facebook";
$l['editor_liveleak'] = "LiveLeak";
$l['editor_insertvideo'] = "Video ekle";
$l['editor_maximize'] = "Tam ekran";

$l['missing_task'] = "Hata: Görev Dosyası Bulunamadı.";
$l['task_backup_cannot_write_backup'] = "Hata: Veritabanı yedeği, (./admin/backups) yedek klasörüne indirilemiyor.<br />Lütfen, yedek klasörünüzün yazma izinlerinin (CHMOD: 777) olup olmadığını kontrol ederek tekrar deneyiniz.";
$l['task_backup_ran'] = "Veritabanı yedekleme görevi, başarılı olarak çalıştırıldı.";
$l['task_checktables_ran'] = "Bozuk tablo kontrol görevi başarılı olarak çalıştırıldı.";
$l['task_checktables_ran_found'] = "Not: Tablo kontrol görevi başarılı olarak çalıştırıldı ve Toplam: {1} tablo onarıldı.";
$l['task_dailycleanup_ran'] = "Günlük temizleme görevi başarılı olarak çalıştırıldı.";
$l['task_hourlycleanup_ran'] = "Saatlik temizleme görevi başarılı olarak çalıştırıldı.";
$l['task_logcleanup_ran'] = "Günlük temizleme görevi başarılı olarak çalıştırıldı ve tüm eski kayıtlar ayıklandı.";
$l['task_promotions_ran'] = "Promosyon görevi başarılı olarak çalıştırıldı.";
$l['task_threadviews_ran'] = "Konu görüntüleme görevi başarılı olarak çalıştırıldı.";
$l['task_usercleanup_ran'] = "Kullanıcı temizleme görevi başarılı olarak çalıştırıldı.";
$l['task_massmail_ran'] = "Toplu E-posta görevi başarılı olarak çalıştırıldı.";
$l['task_userpruning_ran'] = "Kullanıcı ayıklama görevi başarılı olarak çalıştırıldı.";
$l['task_delayedmoderation_ran'] = "Gecikmiş görevler başarılı olarak çalıştırıldı.";
$l['task_massmail_ran_errors'] = "Bir veya birden fazla mesajınız bir hatadan dolayı gönderilemiyor. \"{1}\":
{2}";
$l['task_versioncheck_ran'] = "Sürüm Kontrol Görevi Başarılı Bir Şekilde Tamamlandı.";
$l['task_versioncheck_ran_errors'] = "Sürüm Kontrolü için MyBB ile Bağlantı Kurulamadı.";
$l['task_recachestylesheets_ran'] = '{1} Stil Sayfası Önbelleğini Yeniden Yapılandırdı. (Re-cached)';

$l['massmail_username'] = "Kullanıcı Adı";
$l['email_addr'] = "E-posta Adresi";
$l['board_name'] = "Forum İsmi";
$l['board_url'] = "Forum Linki";

// Unlock ACP
$l['lockout_unlock'] = "Admin Kontrol Paneli Aç";
$l['enter_username_and_token'] = "Lütfen, devam edebilmek için kullanıcı adı ve şifrenizi giriniz.";
$l['unlock_token'] = "Aktivasyon Kodu:";
$l['unlock_account'] = "Hesabı Aç";

// Email message for if an admin account has been locked out
$l['locked_out_subject'] = "{1}, Yönetici Hesabınız Kilitli";
$l['locked_out_message'] = "{1}, Yönetici Hesabınız, {2} - {3} Hatalı Giriş Yapıldığı için kilitlenmiştir.<br/>

Yönetici hesabınızı yeniden açmak için aşağıdaki bağlantıyı adres satırına yapıştırınız.

{4}/{5}/index.php?action=unlock&uid={7}&token={6}

Eğer üsteki bağlantı çalışmazsa, aşağıdaki bağlantıyı kullanınız.

{4}/{5}/index.php?action=unlock

Giriş yapabilmek için aşağıdaki bilgileri girmeniz gerekiyor:

Kullanıcı Adı: {1}

Aktivasyon Kodu: {6}

Teşekkürler,
--------------
{2} - Yönetimi";

$l['comma'] = ", ";
$l['search_for_a_user'] = "Bir kullanıcı ara";

$l['mybb_engine'] = "ÖM/Posta Göndericisi";

// If the language string for "Username" is too cramped in the ACP Login box
// then use this to define how much larger you want the gap to be (in px)
$l['login_field_width'] = "40";

$l['my2fa'] = "2 Faktörlü Kimlik Doğrulama";
$l['my2fa_failed'] = "Kimlik doğrulama kodunuz yanlış.";
$l['my2fa_code'] = "Doğrulama kodunu giriniz.";
$l['my2fa_label'] = "Doğrulama Kodu:";
$l['my2fa_no_codes'] = "Not: Kurtarma kodlarının tümünü kullandıysanız eğer, yeni bir dizi oluşturmak için <a href=\"index.php?module=home-preferences&amp;action=recovery_codes\">kurtarma kodları sayfasını</a> ziyaret ediniz.";
