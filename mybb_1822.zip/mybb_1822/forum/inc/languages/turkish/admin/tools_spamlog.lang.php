﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi 
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['spam_logs']       = 'Spam Kayıtları';
$l['spam_logs_desc']  = 'Bu kısımdan, Bloklanmış kullanıcıların spam kayıtları geçmişini görüntüleyebilirsiniz.';
$l['prune_spam_logs']       = 'Spam Kayıtlarını Ayıkla';
$l['prune_spam_logs_desc']  = 'Bu kısımdan, Seçilen seçeneklere bağlı olarak Spam Kayıtlarını ayıklayabilirsiniz.';
$l['spam_username']   = 'Kullanıcı Adı';
$l['spam_email']      = 'E-Posta Adresi';
$l['spam_ip']         = 'IP Adresi';
$l['spam_date']       = 'Tarih';
$l['spam_confidence'] = 'Seviye';
$l['no_spam_logs'] = 'Hiçbir kullanıcı henüz spam filtreleri tarafından bloklanmamış.';
$l['success_pruned_spam_logs'] = 'Spam Kayıtları başarılı olarak ayıklandı.';
$l['note_logs_locked'] = 'Güvenlik gereği, 24 saatten daha az bir süre içerisinde oluşturulan kayıtlar ayıklanamaz.';
$l['all_usernames'] = 'Tüm Kullanıcılar';
$l['all_emails'] = ' Tüm E-Posta Adresleri';
$l['date_range'] = "Tarih Aralığı:";
$l['days'] = "Günden daha eski kayıtlar";
$l['filter_spam_logs'] = 'Spam Kayıtlarını Filtrele';
$l['asc'] = "Artan";
$l['desc'] = "Azalan";

$l['in'] = "-";
$l['order'] = "";
$l['sort_by'] = "Listeleme Metodu Seç:";
$l['results_per_page'] = "Sayfa Başına Gösterilecek Sonuç:";

