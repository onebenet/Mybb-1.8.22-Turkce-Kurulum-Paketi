﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi 
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['nav_newthread'] = "Yeni Konu";
$l['newthread_in'] = "{1} - Yeni Konu Gönder";
$l['post_new_thread'] = "Yeni Konu Gönder";
$l['thread_subject'] = "Konu Başlığı/Ön Ek:";
$l['your_message'] = "Konu İçeriği:";
$l['post_options'] = "İmza  ve İfade Yönetimi:";
$l['options_sig'] = "<strong>İmza Kullanımı:</strong> İmzanız gösterilsin mi?";
$l['options_emailnotify'] = "<strong>E-posta Bildirimi:</strong> Konuya yazılan her Cevap için otomatik E-posta bildirimi almak istiyorum.";
$l['options_disablesmilies'] = "<strong>İfade Kullanımı:</strong> İfadeler devre dışı bırakılsın mı?";
$l['post_thread'] = "Yeni Konuyu Gönder";
$l['preview_post'] = "Önizleme Yap";
$l['poll'] = "Anket Yönetimi:";
$l['poll_desc'] = "Dilerseniz bu Konuya bir anket ilave edebilirsiniz. (isteğe bağlı)";
$l['poll_check'] = "Evet anket eklemek istiyorum";
$l['num_options'] = "Anket kaç seçenekli olsun?:";
$l['max_options'] = "[En Fazla: {1}]";
$l['mod_options'] = "Moderatör Seçenekleri:";
$l['close_thread'] = "<strong>Konuyu Kapat:</strong> Konu Kapatılsın mı?";
$l['stick_thread'] = "<strong>Konuyu Üstte Tuttur:</strong> Konu Üstte Tutturulsun mu?";
$l['draft_saved'] = "Yeni konunuz başarılı olarak taslaklara kayıtlandı.<br />Şimdi taslak listenize yönlendiriliyorsunuz...";
$l['error_post_already_submitted'] = "Bu foruma aynı konuyu tekrar göndermeye çalışıyorsunuz. Lütfen konunuzu okumak için forumu ziyaret ediniz.";
$l['no_prefix'] = "(Ön Ek Yok)";
$l['forum_rules'] = "{1} - Kurallar";

$l['multiquote_external_one'] = "Başka Konudan 1 Yorum Seçtiniz.";
$l['multiquote_external'] = "Başka Konudan {1} Yorum Seçtiniz.";
$l['multiquote_external_one_deselect'] = "Bu Yorumun Seçimini Kaldır";
$l['multiquote_external_deselect'] = "Bu Yorumların Seçimini Kaldır";
$l['multiquote_external_one_quote'] = "Bu Yorumu Alıntı Yap";
$l['multiquote_external_quote'] = "Çoklu Alıntı Yap";

$l['redirect_newthread'] = "Teşekkürler, konunuz başarılı olarak gönderildi.";
$l['redirect_newthread_poll'] = "<br />Şimdi anket seçeneklerini yapılandırma sayfasına yönlendiriliyorsunuz...";
$l['redirect_newthread_moderation'] = "<br />Forum yöneticisi, tüm Yeni Konu Ve Yorumları moderasyon işlemi gerektirecek şekilde ayarlamış.<br />Şimdi konu listesi ayfasına yönlendiriliyorsunuz...";
$l['redirect_newthread_unviewable'] = "<br />Bu forumdaki konuları görüntülemek için izniniz yok. Şimdi foruma geri yönlendiriliyorsunuz...";
$l['redirect_newthread_thread'] = "<br />Şimdi konuya geri yönlendiriliyorsunuz...";
$l['invalidthread'] = "Belirtilen taslak mevcut değil yada görebilmek için gerekli izniniz yok.";

$l['error_stop_forum_spam_spammer'] = 'Üzgünüz, {1} veritabanımızda kayıtlı bilinen bir spam olarak algılandı. Eğer bunun bir hata olduğunu düşünyorsanız lütfen, iletişim bölümünden forum yöneticisi ile irtibat kurunuz.';
$l['error_stop_forum_spam_fetching'] = 'Üzgünüz, hesabınızın bilinen bir spam olup olmadığını sorgulama sırasında veritabanında bir hata oluştu. Lütfen daha sonra tekrar deneyiniz.';

$l['error_suspendedposting'] = "Üzgünüz, yeni Konu ve Yorum gönderimleriniz; {1} askıya alındı.<br /><br />

Askıya Alınma Tarihi: {2}";
$l['error_suspendedposting_temporal'] = "{1} Tarihine kadar";
$l['error_suspendedposting_permanent'] = "Süresiz olarak";
