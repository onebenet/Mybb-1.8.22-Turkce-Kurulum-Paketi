﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['all_forums'] = "Tüm Forumlar";
$l['forum'] = "Forum:";
$l['posted_by'] = "Yazar:";
$l['on'] = "Açık";
$l['portal'] = "Portal";
