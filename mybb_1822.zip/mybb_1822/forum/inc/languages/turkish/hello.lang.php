<?php
/**
 * MyBB 1.8
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Website: http://www.mybb.com
 * License: http://www.mybb.com/about/license
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['hello'] = 'Merhaba!';
$l['hello_add'] = 'Yeni';
$l['hello_add_message'] = 'Yeni Mesaj';
$l['hello_empty'] = 'Mesaj Bulunamadı.';
$l['hello_message_empty'] = 'Mesaj boş bırakılamaz.';
$l['hello_done'] = 'Yeni mesaj başarıyla eklendi.';