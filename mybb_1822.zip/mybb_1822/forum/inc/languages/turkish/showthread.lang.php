﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['delete_poll'] = "Anketi Sil";
$l['close_thread'] = "Konuyu Kapat?";
$l['stick_thread'] = "Konuyu Üstte Tuttur?";

$l['author'] = "Yazar";
$l['message'] = "Konu";
$l['threaded'] = "Konu Görünümü";
$l['linear'] = "Tam Görünüm";
$l['thread_modes'] = "Gösterim Stili";
$l['next_oldest'] = "Önceki Konu";
$l['next_newest'] = "Sonraki Konu";
$l['view_printable'] = "Konuyu Yazdır";
$l['send_thread'] = "Arkadaşına Gönder";
$l['subscribe_thread'] = "Konuyu Takip Et";
$l['unsubscribe_thread'] = "Takip Etmeyi Bırak";
$l['add_poll_to_thread'] = "Konuya Anket Ekle";
$l['moderation_options'] = "Yönetici Araçları:";
$l['delayed_moderation'] = "Gecikmeli Moderasyonlar";
$l['thread_notes'] = "Konu Notlarını Yönet";
$l['open_close_thread'] = "Konuyu Aç/Kapat";
$l['approve_thread'] = "Konuyu Onayla";
$l['unapprove_thread'] = "Konu Onayını Kaldır";
$l['soft_delete_thread'] = "Konuyu Gizle/Geçici Sil";
$l['restore_thread'] = "Konuyu Göster/Geri Getir";
$l['delete_thread'] = "Konuyu Sil";
$l['delete_posts'] = "Seçili Yorumları Sil";
$l['move_thread'] = "Konuyu Taşı/Kopyala";
$l['stick_unstick_thread'] = "Konuyu Üstte Tuttur/Üstten Kaldır";
$l['split_thread'] = "Konuyu Ayrıştır";
$l['merge_threads'] = "Konuları Birleştir";
$l['merge_posts'] = "Seçili Yorumları Birleştir";
$l['remove_redirects'] = "Yönlendirmeleri İptal Et";
$l['remove_subscriptions'] = "Tüm Takipleri İptal Et";
$l['poll'] = "Anket Başlığı:";
$l['show_results'] = "Anket Sonuçlarını Göster";
$l['edit_poll'] = "Anketi Düzenle";
$l['public_note'] = "<b>Hatırlatma:</b> Bu anket genel bir ankettir. Diğer kullanıcılar sizin hangi seçeneğe oy verdiğinizi görebilirler.";
$l['total'] = "Katılımcı sayısı:";
$l['vote'] = "Oy Kulan!";
$l['total_votes'] = " {1}";
$l['you_voted'] = "* Siz bu anket için oy kullanmışsınız.";
$l['poll_closed'] = "Anket kapatılmıştır.";
$l['poll_closes'] = "Bu anket kapanacaktır: {1}";
$l['already_voted'] = "Siz bu anket için oy kullanmışsınız.";
$l['undo_vote'] = "Oyunu Geri Al";
$l['quick_reply'] = "Hızlı Cevap";
$l['message_options'] = "Seçenekler:";
$l['signature'] = "İmzamı Göster?";
$l['email_notify'] = "E-posta Bildirimi";
$l['disable_smilies'] = "İfadeleri İptal Et?";
$l['post_reply'] = "Cevabı Gönder";
$l['post_reply_img'] = "Yeni Yorum Gönder";
$l['new_reply'] = "Yorum Yaz";
$l['search_button'] = 'Arama';
$l['post_thread'] = "Yeni Konu Gönder";
$l['preview_post'] = "Önizleme Yap";
$l['rating_average'] = "Derecelendirme: {2}/5 - {1} oy";
$l['rate_thread'] = "Bu Konuya Oy Ver:";
$l['thread_rating'] = "Konuyu Oyla:";
$l['similar_threads'] = "Konu ile Alakalı Benzer Konular";
$l['thread'] = "Konular";
$l['replies'] = "Yorumlar";
$l['views'] = "Okunma";
$l['lastpost'] = "Son Yorum";
$l['messages_in_thread'] = "Bu Konudaki Yorumlar";
$l['users_browsing_thread'] = "Konuyu Okuyanlar:";
$l['users_browsing_thread_guests'] = "{1} Ziyaretçi";
$l['users_browsing_thread_invis'] = "{1} Gizli Üye";
$l['users_browsing_thread_reading'] = "Konu okuyor...";
$l['inline_soft_delete_posts'] = "Yorumları Gizle/Geçici Sil";
$l['inline_restore_posts'] = "Yorumları Göster/Geri Getir";
$l['inline_delete_posts'] = "Yorumları Sil";
$l['inline_merge_posts'] = "Yorumları Birleştir";
$l['inline_split_posts'] = "Yorumları Ayrıştır";
$l['inline_move_posts'] = "Yorumları Taşı";
$l['inline_approve_posts'] = "Yorumları Onayla";
$l['inline_unapprove_posts'] = "Yorumların Onayını Kaldır";
$l['inline_post_moderation'] = "Konu Yönetimi:";
$l['inline_go'] = "Git";
$l['clear'] = "İptal Et";
$l['thread_closed'] = "Konu Kapalı";
$l['no_subject'] = "Konu Başlığı Yok";
$l['error_nonextnewest'] = "Bir önceki okumuş olduğunuz konudan başka <b>''Yeni Konu''</b> bulunamadı.";
$l['error_nonextoldest'] = "Bir önceki okumuş olduğunuz konudan başka <b>''Eski Konu''</b> bulunamadı.";
$l['quickreply_multiquote_selected'] = "<b>Alıntı yaparak cevap vermek istiyor musunuz?:</b>";
$l['quickreply_multiquote_now'] = " Alıntı yorumu şimdi ekle";
$l['or'] = " veya";
$l['quickreply_multiquote_deselect'] = "Alıntıyı iptal et";
$l['search_thread'] = "Ara";
$l['enter_keywords'] = "Konu içi Arama..";
$l['view_thread_notes'] = "Konu Notları";

$l['save_changes'] = 'Kaydet';
$l['cancel_edit'] = 'Vazgeç';
$l['quick_edit_update_error'] = 'Cevabınız düzenlenirken bir hata oluştu:';
$l['quick_reply_post_error'] = 'Cevabınız eklenirken bir hata oluştu:';
$l['quick_delete_error'] = 'Cevabınız silinirken bir hata oluştu:';
$l['quick_delete_success'] = 'Mesaj Başarıyla silindi.';
$l['quick_delete_thread_success'] = 'Konu Başarıyla silindi.';
$l['quick_restore_error'] = 'Mesaj onarılırken/geri getirilirken bir hata oluştu:';
$l['quick_restore_success'] = 'Mesaj başarıyla onarılıp/geri getirildi.';

