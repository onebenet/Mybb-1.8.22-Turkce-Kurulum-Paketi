﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['redirect_threadrated'] = "Teşekkürler, oyunuz başarıyla işlendi. Şimdi konuya geri yönlendiriliyorsunuz.";

$l['error_invalidrating'] = "Geçersiz bir oylama yaptın, lütfen geri dönüp tekrar dene.";
$l['error_alreadyratedthread'] = "Üzgünüz, fakat bu konu için daha önce oy kullanmışsın.";
$l['error_cannotrateownthread'] = "Üzgünüz, fakat kendi Konuna oy kullanamazsın.";

$l['rating_votes_average'] = "Derecelendirme: {2}/5 - {1} oy";
$l['one_star'] = "Çok kötü";
$l['two_stars'] = "Kötü";
$l['three_stars'] = "Orta";
$l['four_stars'] = "İyi";
$l['five_stars'] = "Çok iyi";
$l['rating_added'] = "Teşekkürler. Oyunuz İşlendi!";
