﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['archive_fullversion'] = "Orjinalini görmek için tıklayınız:";
$l['archive_replies'] = "Yorum";
$l['archive_reply'] = "Yorum";
$l['archive_pages'] = "Sayfalar:";
$l['archive_note'] = "Şu anda (Arşiv) modunu görüntülemektesiniz.  <a href=\"{1}\">Orjinal Sürümü Görüntüle</a> <img src=\"../images/icons/external_link.png\" style=\"vertical-align: middle;\" width=\"8\" height=\"9\" alt=\"internal link\" border=\"0\" />";
$l['archive_nopermission'] = "Üzgünüz, fakat bu kaynağa erişim izniniz yok.";
$l['error_nothreads'] = "Şu anda bu forumda konu yok veya silinmiş olabilir.";
$l['error_nopermission'] = "Bu forumdaki konuları görüntülemek için izniniz yok.";
$l['error_unapproved_thread'] = "Bu konu onaysız olduğu için görüntüleyemiyorsunuz. Konuyu orjinal sürümde görüntüleyebilmek için <a href=\"{1}\">Buraya</a> tıklayınız.";
$l['archive_not_found'] = "Belirtilen belge veya konu bu forumda bulunamadı.";
$l['error_mustlogin'] = "Bu foruma erişebilmek için giriş yapmanız gerekir.";