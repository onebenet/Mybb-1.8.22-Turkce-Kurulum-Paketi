﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
  * MyBB 1.8.22 Türkçe Dil Paketi  * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır * */

$l['nav_profile'] = "{1}, Nickli Kullanıcının Uyarı Kayıtları";
$l['nav_warning_log'] = "Uyarı Kayıtları";
$l['nav_add_warning'] = "Kullanıcı Uyarı Paneli";
$l['nav_view_warning'] = "Uyarı Bilgileri";

$l['warning_for_post'] = ".. Mesaj:";
$l['already_expired'] = "Bitiş süresi";
$l['details_username'] = "Kullanıcı Adı";
$l['warning_active'] = "Aktif";
$l['warning_revoked'] = "İptal Edildi";
$l['warning_log'] = "Uyarı Kayıtları";
$l['warning'] = "Uyarı Sebebi & Seviyesi";
$l['issued_by'] = "Uyaran Kullanıcı";
$l['date_issued'] = "Uyarı Tarihi";
$l['expiry_date'] = "Bitiş süresi";
$l['active_warnings'] = "Aktif Uyarılar";
$l['expired_warnings'] = "Süresi Biten Uyarılar";
$l['warning_points'] = "(Uyarı Seviyesi: {1})";
$l['no_warnings'] = "Bu kullanıcı ya hiç uyarılmadı ya da tüm uyarıları daha önce silinmiş.";
$l['warn_user'] = "Kullanıcıyı Uyar";
$l['warn_user_desc'] = "Bu Kullanıcının Forum Kurallarını İhlal Ettiğini Düşünüyorsanız Eğer, Bu Kısımdan Gerekli Uyarı Puanı'nı Vererek Cezalandırma Yapabilirsiniz.";
$l['post'] = "Mesaj:";
$l['warning_note'] = "Yönetici Notu:";
$l['details_warning_note'] = "Yönetici Notu";
$l['warning_type'] = "Uyarı Türü:";
$l['custom'] = "Özel Sebep Ekle";
$l['reason'] = "Özel Sebep:";
$l['points'] = "Uyarı Seviyesi:";
$l['details_reason'] = "Sebep";
$l['send_pm'] = "Kullanıcı Bildirimi:";
$l['send_user_warning_pm'] = "Bu uyarı hakkında, kullanıcıya uyarıldığına dair özel mesaj gönderebilirsiniz.";
$l['send_pm_subject'] = "Başlık:";
$l['warning_pm_subject'] = "Bir Uyarı Aldınız!";
$l['send_pm_message'] = "Mesaj:";
$l['warning_pm_message'] = "Merhaba {1},

Forum yönetiminden, kuralları ihlal ettiğininizden dolayı bir uyarı aldınız!

Uyarı hakkında ayrıntılı bilgiye profil sayfanızdaki, (uyarı seviyesi) kısmından bakabilirsiniz. Ayrıca forum kurallarını okuyarak neden uyarı verildiğine dair detaylı bilgi sahibi olabilirsiniz..

Uyarı Özeti:
..?

Saygılarımızla,
------------------
{2} - Yönetimi";
$l['send_pm_options'] = "Seçenekler:";
$l['send_pm_options_anonymous'] = "<strong>Anonim ÖM</strong>: Anonim/Gizli bir kullanıcı olarak bu özel mesajı gönder.";
$l['expiration_never'] = "Kalıcı olarak";
$l['expiration_hours'] = "Saat";
$l['expiration_days'] = "Gün";
$l['expiration_weeks'] = "Hafta";
$l['expiration_months'] = "Ay";
$l['redirect_warned_banned'] = "<br /><br />Kullanıcı {1} Grubundan, {2} Grubuna Taşındı.";
$l['redirect_warned_suspended'] = "<br /><br />Bu kullanıcının Yeni Konu ve Yeni Yorum gönderimleri Askıya Alınmıştır {1}.";
$l['redirect_warned_moderate'] = "<br /><br />Bu Kullanıcının Tüm Mesajları {1} Tarafından Düzenlenmiştir.";
$l['redirect_warned_pmerror'] = "<br /><br />ÖM bildirimi ile uyarı gönderildiği için herhangi bir yönetici notu mevcut değil.";
$l['redirect_warned'] = "{1}, Nickli Kullanıcının Uyarı Seviyesi, %{2}. {3}, Seviyesine Yükseltilmiştir.<br /><br />Şimdi Geldiğiniz Yere Geri Yönlendiriliyorsunuz...";
$l['error_warning_system_disabled'] = "Uyarı Sistemini Kullanamazsınız. Çünkü Forum Yönetimi Tarafından Kullanıma Kapatılmıştır.";
$l['error_cant_warn_group'] = "Bu Grubtaki Kullanıcıları Uyarmak İçin Gerekli İzniniz Yok.";
$l['error_invalid_user'] = "Seçmiş Olduğunuz Kullanıcı Bulunamadı.";
$l['details'] = "Detaylar";
$l['view'] = "İncele";
$l['current_warning_level'] = "Şu anki Uyarı Yüzdesi: <strong>%{1}</strong> - Seviye: <strong>{2}/{3}</strong>";
$l['warning_details'] = "Uyarı Bilgileri";
$l['revoke_warning'] = "Bu Uyarıyı İptal Et";
$l['revoke_warning_desc'] = "Bu uyarıyı iptal etmek için aşağıdaki metin editörüne bir sebep giriniz.";
$l['warning_is_revoked'] = "Bu Uyarı İptal Edilmiştir.";
$l['revoked_by'] = "İptal Eden";
$l['date_revoked'] = "İptal Tarihi";
$l['warning_already_revoked'] = "Bu Uyarı Zaten İptal Edilmiş.";
$l['no_revoke_reason'] = "Bu Uyarı Neden İptal Etmek İstediğinize Dair Bir Sebeb Belirtmediniz.";
$l['redirect_warning_revoked'] = "Bu Uyarı Başarılı Olarak İptal Edilip, Kullanıcının Uyarı Seviyesi Azaltılmıştır.<br /><br />Şimdi Uyarı Bölümüne Geri Yönlendiriliyorsunuz...";
$l['result'] = "Sonuç:";
$l['result_banned'] = "Cezalandırılan Kullanıcı ({1}) , {2} Grubuna Taşındı.";
$l['result_suspended'] = "{1} Mesaj Ayrıcaklıkları Askıya Alınacak.";
$l['result_moderated'] = "{1} Mesajlarına Moderasyon İşlemi Uygulanacak.";
$l['result_period'] = "{1} , {2}";
$l['result_period_perm'] = "süresiz";
$l['hour_or_hours'] = "Saat";
$l['day_or_days'] = "Gün";
$l['week_or_weeks'] = "Hafta";
$l['month_or_months'] = "Ay";
$l['expires'] = "Bitiş Süresi:";
$l['new_warning_level'] = "Yeni Uyarı Seviyesi:";
$l['cannot_warn_self'] = "Kendi Kendinize Uyarı Veremezsiniz.";
$l['error_cant_warn_user'] = "Bu Kullanıcıyı Uyarmak İçin İzniniz Yok.";
$l['existing_post_warnings'] = "Bu Mesaj İçin Mevcut Uyarılar.";
