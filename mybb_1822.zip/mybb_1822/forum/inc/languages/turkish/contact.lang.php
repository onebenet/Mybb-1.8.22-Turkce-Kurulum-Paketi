﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi 
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['contact'] = 'İletişim Formu';
$l['contact_no_message'] = 'Gönderilecek bir mesaj girmediniz. Lütfen e-postanız için kısa ve açıklayı bir mesaj giriniz.';
$l['contact_no_subject'] = 'E-posta başlığı girmediniz. Lütfen bir başlık giriniz.';
$l['contact_no_email'] = 'E-posta adresiniz geçerli değil. Lütfen geçerli bir e-posta adresi giriniz.';
$l['contact_success_message'] = 'Teşekkürler. Mesajınız başarıyla yöneticiye gönderildi.';
$l['contact_subject'] = 'Başlık';
$l['contact_subject_desc'] = 'Lütfen, iletişim için bir başlık giriniz.';
$l['contact_message'] = 'Mesajınız';
$l['contact_message_desc'] = 'Göndermek istediğiniz mesaj hakkında detayları bu alana giriniz.';
$l['contact_email'] = 'E-posta Adresiniz';
$l['contact_email_desc'] = 'Geri dönüş için irtibat kurulmasını istediğiniz e-posta adresinizi giriniz.';
$l['contact_send'] = 'Gönder';
$l['subject_too_long'] = 'E-posta başlığı çok uzun. Lütfen <b>{1}</b> karakterden daha kısa bir başlık giriniz. (Şu anda girilen karakter sayısı: <b>{2}</b>) .';
$l['message_too_short'] = 'Mesaj içeriği ya çok kısa ya da henüz hiçbir şey yazmadınız. Lütfen <b>{1}</b> karakterden daha uzun bir içerik giriniz. (Şu anda girilen karakter sayısı: <b>{2}</b>)';
$l['message_too_long'] = 'Mesaj içeriği çok uzun. Lütfen <b>{1}</b> karakterden daha kısa bir içerik giriniz. (Şu anda girilen karakter sayısı: <b>{2}</b>)';

$l['error_stop_forum_spam_spammer'] = 'Üzgünüz, {1} bilinen bir spam ile eşleştiği tespit edildi. Bu sepeten dolayı iletişim formu ile e-posta gönderiminiz bloke edilmiştir.';
$l['error_stop_forum_spam_fetching'] = 'Üzgünüz fakat, spam doğrulaması için veritabanı ile bağlantı kurulamadığından dolayı e-postanız gönderilemedi. Lütfen daha sonra tekrar deneyiniz.';

