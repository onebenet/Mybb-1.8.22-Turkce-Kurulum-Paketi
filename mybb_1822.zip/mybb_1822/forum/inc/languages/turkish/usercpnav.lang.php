﻿	<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['ucp_nav_width'] = "185";
$l['ucp_nav_menu'] = "Kontrol Panel Araçları";
$l['ucp_nav_messenger'] = "Özel Mesaj Yönetimi";
$l['ucp_nav_compose'] = "Yeni Mesaj Gönder";
$l['ucp_nav_tracking'] = "Özel Mesaj Takibi";
$l['ucp_nav_edit_folders'] = "Klasör Yönetimi";
$l['ucp_nav_profile'] = "Hesap Yönetimi";
$l['ucp_nav_edit_profile'] = "Bilgilerini Düzenle";
$l['ucp_nav_edit_options'] = "Hesap Seçenekleri";
$l['ucp_nav_change_email'] = "E-Postanı Değiştir";
$l['ucp_nav_change_pass'] = "Şifreni Değiştir";
$l['ucp_nav_change_username'] = "Kullanıcı Adını Değiştir";
$l['ucp_nav_edit_sig'] = "İmzanı Değiştir";
$l['ucp_nav_change_avatar'] = "Avatarını Değiştir";
$l['ucp_nav_misc'] = "Diğer Araçlar";
$l['ucp_nav_editlists'] = "Arkadaşlar & Engelli Listesi";
$l['ucp_nav_favorite_threads'] = "Favori Konular";
$l['ucp_nav_subscribed_threads'] = "Takip Edilen Konular";
$l['ucp_nav_forum_subscriptions'] = "Takip Edilen Forumlar";
$l['ucp_nav_drafts'] = "Kayıtlı Taslaklar";
$l['ucp_nav_drafts_active'] = "Kayıtlı Taslaklar: ({1})";
$l['ucp_nav_notepad'] = "Kişisel Notlar";
$l['ucp_nav_view_profile'] = "Profilini Gör";
$l['ucp_nav_home'] = "Kullanıcı KP Anasayfa";
$l['ucp_nav_usergroups'] = "Grup üyelikleri";
$l['ucp_nav_attachments'] = "Ek Dosya Yönetimi";
