﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['error_no_connection'] = "Sunucu İle Bağlantı Kurulurken Bir Hata Oluştu:";
$l['error_no_message'] = "Hiçbir Mesaj Belirtilmemiş.";
$l['error_no_subject'] = "Hiçbir Konu Belirtilmemiş.";
$l['error_no_recipient'] = "Hiçbir Alıcı Belirtilmemiş.";
$l['error_not_sent'] = "Hata: PHP Mail Fonksiyonu, Mail Göndermeye Çalışırken Bir Sorunla Karşılaştı. Lütfen Daha Sonra Tekrar Deneyiniz.";
$l['error_status_missmatch'] = "Sunucuya Dönen Sonuçlar Beklenirken Oluşan Uyumsuzluklar: ";
$l['error_data_not_sent'] = "Şu Veriler Sunucuya Gönderilemedi: ";

$l['error_occurred'] = "Bir Veya Daha Fazla Hata Oluştu. Lütfen Devam Etmeden önce Aşağıdaki Hataları Düzeltiniz.<br />";
